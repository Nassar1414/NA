import os
import numpy as np
import matplotlib.pyplot as plt
import cv2
from tensorflow.keras.preprocessing.image import load_img, img_to_array
import random
from sklearn.model_selection import train_test_split

# Define paths
DATA_DIR = '/home/ubuntu/driver_drowsiness_detection/data'
TRAIN_DIR = os.path.join(DATA_DIR, 'train')
CATEGORIES = ['Closed', 'Open', 'no_yawn', 'yawn']

def analyze_dataset_distribution():
    """
    Analyze the distribution of images across categories
    """
    print("Analyzing dataset distribution...")
    
    # Count images in each category
    category_counts = {}
    for category in CATEGORIES:
        category_path = os.path.join(TRAIN_DIR, category)
        if os.path.exists(category_path):
            images = os.listdir(category_path)
            category_counts[category] = len(images)
    
    # Print distribution
    total_images = sum(category_counts.values())
    print(f"Total images: {total_images}")
    for category, count in category_counts.items():
        print(f"{category}: {count} images ({count/total_images*100:.2f}%)")
    
    # Plot distribution
    plt.figure(figsize=(10, 6))
    plt.bar(category_counts.keys(), category_counts.values())
    plt.title('Dataset Distribution')
    plt.xlabel('Category')
    plt.ylabel('Number of Images')
    plt.savefig(os.path.join(DATA_DIR, 'dataset_distribution.png'))
    plt.close()

def analyze_image_properties():
    """
    Analyze image properties (size, channels, etc.)
    """
    print("\nAnalyzing image properties...")
    
    # Sample images from each category
    image_sizes = []
    image_channels = []
    
    for category in CATEGORIES:
        category_path = os.path.join(TRAIN_DIR, category)
        if os.path.exists(category_path):
            images = os.listdir(category_path)
            # Sample up to 50 images from each category
            sample_size = min(50, len(images))
            sampled_images = random.sample(images, sample_size)
            
            for image_name in sampled_images:
                image_path = os.path.join(category_path, image_name)
                try:
                    img = cv2.imread(image_path)
                    if img is not None:
                        height, width, channels = img.shape
                        image_sizes.append((width, height))
                        image_channels.append(channels)
                except Exception as e:
                    print(f"Error processing {image_path}: {e}")
    
    # Analyze sizes
    widths, heights = zip(*image_sizes)
    unique_sizes = set(image_sizes)
    
    print(f"Number of unique image sizes: {len(unique_sizes)}")
    print(f"Most common image sizes:")
    for size, count in sorted([(size, image_sizes.count(size)) for size in unique_sizes], 
                             key=lambda x: x[1], reverse=True)[:5]:
        print(f"  {size}: {count} images")
    
    print(f"Width range: {min(widths)} to {max(widths)}")
    print(f"Height range: {min(heights)} to {max(heights)}")
    
    # Analyze channels
    unique_channels = set(image_channels)
    print(f"Number of unique channel configurations: {len(unique_channels)}")
    for channels in unique_channels:
        print(f"  {channels} channels: {image_channels.count(channels)} images")
    
    # Plot size distribution
    plt.figure(figsize=(12, 6))
    plt.subplot(1, 2, 1)
    plt.hist(widths, bins=20)
    plt.title('Width Distribution')
    plt.xlabel('Width (pixels)')
    plt.ylabel('Count')
    
    plt.subplot(1, 2, 2)
    plt.hist(heights, bins=20)
    plt.title('Height Distribution')
    plt.xlabel('Height (pixels)')
    plt.ylabel('Count')
    
    plt.tight_layout()
    plt.savefig(os.path.join(DATA_DIR, 'image_size_distribution.png'))
    plt.close()

def visualize_sample_images():
    """
    Visualize sample images from each category
    """
    print("\nVisualizing sample images...")
    
    plt.figure(figsize=(15, 10))
    
    for i, category in enumerate(CATEGORIES):
        category_path = os.path.join(TRAIN_DIR, category)
        if os.path.exists(category_path):
            images = os.listdir(category_path)
            # Sample 5 random images from each category
            sample_size = min(5, len(images))
            sampled_images = random.sample(images, sample_size)
            
            for j, image_name in enumerate(sampled_images):
                image_path = os.path.join(category_path, image_name)
                try:
                    img = cv2.imread(image_path)
                    if img is not None:
                        # Convert BGR to RGB
                        img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
                        
                        plt.subplot(len(CATEGORIES), sample_size, i*sample_size + j + 1)
                        plt.imshow(img)
                        plt.title(f"{category}")
                        plt.axis('off')
                except Exception as e:
                    print(f"Error visualizing {image_path}: {e}")
    
    plt.tight_layout()
    plt.savefig(os.path.join(DATA_DIR, 'sample_images.png'))
    plt.close()

def analyze_pixel_intensity():
    """
    Analyze pixel intensity distribution
    """
    print("\nAnalyzing pixel intensity distribution...")
    
    intensity_distributions = {category: [] for category in CATEGORIES}
    
    for category in CATEGORIES:
        category_path = os.path.join(TRAIN_DIR, category)
        if os.path.exists(category_path):
            images = os.listdir(category_path)
            # Sample up to 50 images from each category
            sample_size = min(50, len(images))
            sampled_images = random.sample(images, sample_size)
            
            for image_name in sampled_images:
                image_path = os.path.join(category_path, image_name)
                try:
                    img = cv2.imread(image_path, cv2.IMREAD_GRAYSCALE)
                    if img is not None:
                        # Flatten and add to distribution
                        intensity_distributions[category].extend(img.flatten())
                except Exception as e:
                    print(f"Error processing {image_path}: {e}")
    
    # Plot intensity distributions
    plt.figure(figsize=(15, 10))
    
    for i, (category, intensities) in enumerate(intensity_distributions.items()):
        plt.subplot(2, 2, i+1)
        plt.hist(intensities, bins=50, alpha=0.7)
        plt.title(f"{category} Pixel Intensity Distribution")
        plt.xlabel('Pixel Intensity')
        plt.ylabel('Count')
    
    plt.tight_layout()
    plt.savefig(os.path.join(DATA_DIR, 'pixel_intensity_distribution.png'))
    plt.close()

def create_train_val_test_split():
    """
    Create proper train/validation/test splits
    """
    print("\nCreating train/validation/test splits...")
    
    # Create directories for splits
    os.makedirs(os.path.join(DATA_DIR, 'train_split'), exist_ok=True)
    os.makedirs(os.path.join(DATA_DIR, 'val_split'), exist_ok=True)
    os.makedirs(os.path.join(DATA_DIR, 'test_split'), exist_ok=True)
    
    for category in CATEGORIES:
        # Create category directories in each split
        os.makedirs(os.path.join(DATA_DIR, 'train_split', category), exist_ok=True)
        os.makedirs(os.path.join(DATA_DIR, 'val_split', category), exist_ok=True)
        os.makedirs(os.path.join(DATA_DIR, 'test_split', category), exist_ok=True)
        
        category_path = os.path.join(TRAIN_DIR, category)
        if os.path.exists(category_path):
            images = os.listdir(category_path)
            
            # Split into train (70%), validation (15%), and test (15%)
            train_images, temp_images = train_test_split(images, test_size=0.3, random_state=42)
            val_images, test_images = train_test_split(temp_images, test_size=0.5, random_state=42)
            
            print(f"{category}: {len(train_images)} train, {len(val_images)} validation, {len(test_images)} test")
            
            # Copy images to respective directories
            for image_set, target_dir in [(train_images, 'train_split'), 
                                         (val_images, 'val_split'), 
                                         (test_images, 'test_split')]:
                for image_name in image_set:
                    src_path = os.path.join(category_path, image_name)
                    dst_path = os.path.join(DATA_DIR, target_dir, category, image_name)
                    
                    # Use symbolic links to save space
                    if not os.path.exists(dst_path):
                        os.symlink(src_path, dst_path)

def suggest_improvements():
    """
    Suggest improvements based on analysis
    """
    print("\nSuggesting improvements based on analysis...")
    
    suggestions = [
        "1. Standardize image sizes: Resize all images to a consistent size (e.g., 128x128 or 224x224)",
        "2. Normalize pixel values: Scale pixel values to [0,1] range",
        "3. Apply data augmentation: Rotation, flipping, brightness/contrast adjustments",
        "4. Use proper train/validation/test splits: 70%/15%/15% split",
        "5. Try transfer learning: Use pre-trained models like MobileNet or EfficientNet",
        "6. Implement batch normalization: Add after each convolutional layer",
        "7. Use dropout for regularization: Add dropout layers to prevent overfitting",
        "8. Experiment with learning rates: Try learning rate schedules or warmup",
        "9. Ensemble models: Combine predictions from multiple models",
        "10. Use proper evaluation metrics: Accuracy, precision, recall, F1-score"
    ]
    
    for suggestion in suggestions:
        print(suggestion)
    
    # Write suggestions to file
    with open(os.path.join(DATA_DIR, 'improvement_suggestions.txt'), 'w') as f:
        f.write("Improvement Suggestions for Driver Drowsiness Detection System\n")
        f.write("==========================================================\n\n")
        for suggestion in suggestions:
            f.write(f"{suggestion}\n\n")

if __name__ == "__main__":
    # Create analysis directory
    os.makedirs(os.path.join(DATA_DIR, 'analysis'), exist_ok=True)
    
    # Run analysis functions
    analyze_dataset_distribution()
    analyze_image_properties()
    visualize_sample_images()
    analyze_pixel_intensity()
    create_train_val_test_split()
    suggest_improvements()
    
    print("\nAnalysis complete! Check the data directory for results.")
