import os
import numpy as np
import tensorflow as tf
from tensorflow.keras.applications import MobileNetV2, ResNet50
from tensorflow.keras.models import Model
from tensorflow.keras.layers import GlobalAveragePooling2D, Dense, Dropout, Input
from tqdm import tqdm

# Define constants
IMG_SIZE = 224
DATA_DIR = '/home/ubuntu/driver_drowsiness_detection/data'
PROCESSED_DIR = os.path.join(DATA_DIR, 'processed')
FEATURES_DIR = os.path.join(DATA_DIR, 'features')
MODELS_DIR = '/home/ubuntu/driver_drowsiness_detection/models'
CATEGORIES = ['Closed', 'Open', 'no_yawn', 'yawn']

def create_feature_extractor(model_name='mobilenet'):
    """
    Create a feature extractor model based on pre-trained CNN
    
    Parameters:
    -----------
    model_name : str
        Name of the pre-trained model to use ('mobilenet' or 'resnet')
        
    Returns:
    --------
    model : tensorflow.keras.Model
        Feature extractor model
    """
    print(f"Creating feature extractor using {model_name}...")
    
    # Create directories
    os.makedirs(FEATURES_DIR, exist_ok=True)
    os.makedirs(MODELS_DIR, exist_ok=True)
    
    # Define input shape
    input_shape = (IMG_SIZE, IMG_SIZE, 1)  # Grayscale images
    
    # Create input layer
    inputs = Input(shape=input_shape)
    
    # Convert grayscale to RGB by repeating the channel
    x = tf.keras.layers.Concatenate()([inputs, inputs, inputs])
    
    # Load pre-trained model without top layers
    if model_name.lower() == 'mobilenet':
        base_model = MobileNetV2(include_top=False, weights='imagenet', input_shape=(IMG_SIZE, IMG_SIZE, 3))
    elif model_name.lower() == 'resnet':
        base_model = ResNet50(include_top=False, weights='imagenet', input_shape=(IMG_SIZE, IMG_SIZE, 3))
    else:
        raise ValueError(f"Unsupported model name: {model_name}")
    
    # Freeze base model layers
    for layer in base_model.layers:
        layer.trainable = False
    
    # Connect base model to our input
    x = base_model(x)
    
    # Add global average pooling
    x = GlobalAveragePooling2D()(x)
    
    # Create model
    model = Model(inputs=inputs, outputs=x, name=f"{model_name}_feature_extractor")
    
    # Save model
    model.save(os.path.join(MODELS_DIR, f"{model_name}_feature_extractor.h5"))
    
    print(f"Feature extractor created and saved to {os.path.join(MODELS_DIR, f'{model_name}_feature_extractor.h5')}")
    
    return model

def extract_features(model, split='train'):
    """
    Extract features from preprocessed images
    
    Parameters:
    -----------
    model : tensorflow.keras.Model
        Feature extractor model
    split : str
        Data split to process ('train', 'val', or 'test')
    """
    print(f"Extracting features for {split} split...")
    
    # Create output directory
    split_features_dir = os.path.join(FEATURES_DIR, split)
    os.makedirs(split_features_dir, exist_ok=True)
    
    for category in CATEGORIES:
        print(f"  Processing {category}...")
        
        # Create category directory
        category_features_dir = os.path.join(split_features_dir, category)
        os.makedirs(category_features_dir, exist_ok=True)
        
        # Get preprocessed images
        category_path = os.path.join(PROCESSED_DIR, split, category)
        if not os.path.exists(category_path):
            print(f"  Warning: Category path {category_path} does not exist")
            continue
        
        preprocessed_files = [f for f in os.listdir(category_path) if f.endswith('.npy')]
        
        for file in tqdm(preprocessed_files, desc=f"  Extracting {category} features"):
            # Load preprocessed image
            image_path = os.path.join(category_path, file)
            image = np.load(image_path)
            
            # Ensure correct shape
            if len(image.shape) == 3 and image.shape[2] == 1:
                # Add batch dimension
                image = np.expand_dims(image, axis=0)
                
                # Extract features
                features = model.predict(image, verbose=0)
                
                # Save features
                output_path = os.path.join(category_features_dir, file)
                np.save(output_path, features)
            else:
                print(f"  Warning: Unexpected image shape {image.shape} for {image_path}")

def create_feature_datasets():
    """
    Create numpy datasets from extracted features
    """
    print("Creating feature datasets...")
    
    for split in ['train', 'val', 'test']:
        print(f"  Processing {split} split...")
        
        features_list = []
        labels_list = []
        
        for i, category in enumerate(CATEGORIES):
            category_path = os.path.join(FEATURES_DIR, split, category)
            
            if not os.path.exists(category_path):
                print(f"  Warning: Category path {category_path} does not exist")
                continue
            
            feature_files = [f for f in os.listdir(category_path) if f.endswith('.npy')]
            
            for file in feature_files:
                # Load features
                feature_path = os.path.join(category_path, file)
                feature = np.load(feature_path)
                
                # Add to lists
                features_list.append(feature.squeeze())
                labels_list.append(i)
        
        # Convert to numpy arrays
        X = np.array(features_list)
        y = np.array(labels_list)
        
        # Save datasets
        np.save(os.path.join(FEATURES_DIR, f"X_{split}.npy"), X)
        np.save(os.path.join(FEATURES_DIR, f"y_{split}.npy"), y)
        
        print(f"  {split.capitalize()} dataset: {X.shape[0]} samples, {X.shape[1]} features")

def visualize_feature_distribution():
    """
    Visualize feature distribution using PCA
    """
    print("Visualizing feature distribution...")
    
    try:
        from sklearn.decomposition import PCA
        import matplotlib.pyplot as plt
        
        # Load training features
        X_train = np.load(os.path.join(FEATURES_DIR, "X_train.npy"))
        y_train = np.load(os.path.join(FEATURES_DIR, "y_train.npy"))
        
        # Apply PCA
        pca = PCA(n_components=2)
        X_pca = pca.fit_transform(X_train)
        
        # Plot
        plt.figure(figsize=(10, 8))
        
        for i, category in enumerate(CATEGORIES):
            mask = (y_train == i)
            plt.scatter(X_pca[mask, 0], X_pca[mask, 1], label=category, alpha=0.7)
        
        plt.title('Feature Distribution (PCA)')
        plt.xlabel('Principal Component 1')
        plt.ylabel('Principal Component 2')
        plt.legend()
        plt.grid(True, alpha=0.3)
        
        plt.savefig(os.path.join(FEATURES_DIR, 'feature_distribution.png'))
        plt.close()
        
        print(f"Feature distribution visualization saved to {os.path.join(FEATURES_DIR, 'feature_distribution.png')}")
    except Exception as e:
        print(f"Error visualizing feature distribution: {e}")

if __name__ == "__main__":
    # Create feature extractor
    model = create_feature_extractor(model_name='mobilenet')
    
    # Extract features for each split
    for split in ['train', 'val', 'test']:
        extract_features(model, split)
    
    # Create feature datasets
    create_feature_datasets()
    
    # Visualize feature distribution
    visualize_feature_distribution()
    
    print("Feature extraction complete!")
