import os
import numpy as np
import cv2
from tensorflow.keras.preprocessing.image import ImageDataGenerator
import matplotlib.pyplot as plt
from tqdm import tqdm

# Define paths
DATA_DIR = '/home/ubuntu/driver_drowsiness_detection/data'
TRAIN_DIR = os.path.join(DATA_DIR, 'train')
CATEGORIES = ['Closed', 'Open', 'no_yawn', 'yawn']

# Create simulated dataset
def generate_simulated_dataset(num_samples=100):
    """
    Generate simulated dataset for drowsiness detection
    
    Parameters:
    -----------
    num_samples : int
        Number of samples to generate per category
    """
    print("Generating simulated dataset...")
    
    # Create directories if they don't exist
    for category in CATEGORIES:
        os.makedirs(os.path.join(TRAIN_DIR, category), exist_ok=True)
    
    # Generate images for each category
    for category in CATEGORIES:
        print(f"Generating {num_samples} images for category: {category}")
        
        for i in tqdm(range(num_samples)):
            # Create a base image (grayscale for simplicity)
            img_size = 64
            img = np.zeros((img_size, img_size), dtype=np.uint8)
            
            if category == 'Closed':
                # Simulate closed eyes (horizontal lines)
                y_center = img_size // 2
                thickness = np.random.randint(2, 5)
                cv2.line(img, (10, y_center), (img_size-10, y_center), 255, thickness)
                
                # Add some noise and variation
                img = add_noise(img)
                
            elif category == 'Open':
                # Simulate open eyes (ellipses)
                center_x, center_y = img_size // 2, img_size // 2
                axes_length = (np.random.randint(15, 25), np.random.randint(8, 15))
                cv2.ellipse(img, (center_x, center_y), axes_length, 0, 0, 360, 255, -1)
                
                # Add pupil
                pupil_size = np.random.randint(5, 10)
                cv2.circle(img, (center_x, center_y), pupil_size, 0, -1)
                
                # Add some noise and variation
                img = add_noise(img)
                
            elif category == 'no_yawn':
                # Simulate mouth closed (horizontal line)
                y_center = img_size // 2 + 10
                thickness = np.random.randint(2, 4)
                cv2.line(img, (20, y_center), (img_size-20, y_center), 255, thickness)
                
                # Add some noise and variation
                img = add_noise(img)
                
            elif category == 'yawn':
                # Simulate yawning mouth (ellipse)
                center_x, center_y = img_size // 2, img_size // 2 + 10
                axes_length = (np.random.randint(15, 25), np.random.randint(10, 20))
                cv2.ellipse(img, (center_x, center_y), axes_length, 0, 0, 360, 255, -1)
                
                # Add some noise and variation
                img = add_noise(img)
            
            # Save the image
            img_path = os.path.join(TRAIN_DIR, category, f"{category}_{i}.jpg")
            cv2.imwrite(img_path, img)
    
    print("Dataset generation complete!")

def add_noise(image, noise_factor=0.1):
    """Add random noise to an image"""
    noise = np.random.randn(*image.shape) * noise_factor * 255
    noisy_image = image + noise
    return np.clip(noisy_image, 0, 255).astype(np.uint8)

def visualize_samples():
    """Visualize sample images from each category"""
    plt.figure(figsize=(12, 8))
    
    for i, category in enumerate(CATEGORIES):
        category_path = os.path.join(TRAIN_DIR, category)
        images = os.listdir(category_path)
        
        if images:
            # Display 5 random images from each category
            for j in range(min(5, len(images))):
                sample_idx = np.random.randint(0, len(images))
                sample_path = os.path.join(category_path, images[sample_idx])
                
                img = cv2.imread(sample_path, cv2.IMREAD_GRAYSCALE)
                
                plt.subplot(4, 5, i*5 + j + 1)
                plt.imshow(img, cmap='gray')
                plt.title(f"{category}")
                plt.axis('off')
    
    plt.tight_layout()
    plt.savefig(os.path.join(DATA_DIR, 'sample_images.png'))
    print(f"Sample visualization saved to {os.path.join(DATA_DIR, 'sample_images.png')}")

if __name__ == "__main__":
    # Generate the dataset
    generate_simulated_dataset(num_samples=100)
    
    # Visualize samples
    visualize_samples()
