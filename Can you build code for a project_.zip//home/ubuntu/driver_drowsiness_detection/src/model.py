import os
import numpy as np
import tensorflow as tf
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Conv2D, MaxPooling2D, Flatten, Dense, Dropout, BatchNormalization
from tensorflow.keras.optimizers import Adam
from tensorflow.keras.callbacks import ModelCheckpoint, EarlyStopping, ReduceLROnPlateau
from tensorflow.keras.preprocessing.image import ImageDataGenerator
import matplotlib.pyplot as plt

# Define constants
IMG_SIZE = 64
BATCH_SIZE = 32
EPOCHS = 20
NUM_CLASSES = 2  # Binary classification (open/closed for eyes, yawn/no_yawn for mouth)
LEARNING_RATE = 0.001

def create_eye_model():
    """
    Create a CNN model for eye state classification (open/closed)
    
    Returns:
    --------
    model : tf.keras.Model
        Compiled CNN model for eye state classification
    """
    model = Sequential([
        # First Convolutional Block
        Conv2D(32, (3, 3), padding='same', activation='relu', input_shape=(IMG_SIZE, IMG_SIZE, 1)),
        BatchNormalization(),
        Conv2D(32, (3, 3), padding='same', activation='relu'),
        BatchNormalization(),
        MaxPooling2D(pool_size=(2, 2)),
        Dropout(0.25),
        
        # Second Convolutional Block
        Conv2D(64, (3, 3), padding='same', activation='relu'),
        BatchNormalization(),
        Conv2D(64, (3, 3), padding='same', activation='relu'),
        BatchNormalization(),
        MaxPooling2D(pool_size=(2, 2)),
        Dropout(0.25),
        
        # Third Convolutional Block
        Conv2D(128, (3, 3), padding='same', activation='relu'),
        BatchNormalization(),
        Conv2D(128, (3, 3), padding='same', activation='relu'),
        BatchNormalization(),
        MaxPooling2D(pool_size=(2, 2)),
        Dropout(0.25),
        
        # Fully Connected Layers
        Flatten(),
        Dense(512, activation='relu'),
        BatchNormalization(),
        Dropout(0.5),
        Dense(NUM_CLASSES, activation='softmax')  # 2 classes: open, closed
    ])
    
    # Compile the model
    model.compile(
        optimizer=Adam(learning_rate=LEARNING_RATE),
        loss='categorical_crossentropy',
        metrics=['accuracy']
    )
    
    return model

def create_yawn_model():
    """
    Create a CNN model for yawn detection (yawn/no_yawn)
    
    Returns:
    --------
    model : tf.keras.Model
        Compiled CNN model for yawn detection
    """
    model = Sequential([
        # First Convolutional Block
        Conv2D(32, (3, 3), padding='same', activation='relu', input_shape=(IMG_SIZE, IMG_SIZE, 1)),
        BatchNormalization(),
        Conv2D(32, (3, 3), padding='same', activation='relu'),
        BatchNormalization(),
        MaxPooling2D(pool_size=(2, 2)),
        Dropout(0.25),
        
        # Second Convolutional Block
        Conv2D(64, (3, 3), padding='same', activation='relu'),
        BatchNormalization(),
        Conv2D(64, (3, 3), padding='same', activation='relu'),
        BatchNormalization(),
        MaxPooling2D(pool_size=(2, 2)),
        Dropout(0.25),
        
        # Third Convolutional Block
        Conv2D(128, (3, 3), padding='same', activation='relu'),
        BatchNormalization(),
        Conv2D(128, (3, 3), padding='same', activation='relu'),
        BatchNormalization(),
        MaxPooling2D(pool_size=(2, 2)),
        Dropout(0.25),
        
        # Fully Connected Layers
        Flatten(),
        Dense(512, activation='relu'),
        BatchNormalization(),
        Dropout(0.5),
        Dense(NUM_CLASSES, activation='softmax')  # 2 classes: yawn, no_yawn
    ])
    
    # Compile the model
    model.compile(
        optimizer=Adam(learning_rate=LEARNING_RATE),
        loss='categorical_crossentropy',
        metrics=['accuracy']
    )
    
    return model

def prepare_data_generators():
    """
    Prepare data generators for training, validation, and testing
    
    Returns:
    --------
    train_generator_eyes : tf.keras.preprocessing.image.DirectoryIterator
        Generator for eye training data
    validation_generator_eyes : tf.keras.preprocessing.image.DirectoryIterator
        Generator for eye validation data
    train_generator_yawn : tf.keras.preprocessing.image.DirectoryIterator
        Generator for yawn training data
    validation_generator_yawn : tf.keras.preprocessing.image.DirectoryIterator
        Generator for yawn validation data
    """
    # Data augmentation for training
    train_datagen = ImageDataGenerator(
        rescale=1./255,
        rotation_range=10,
        width_shift_range=0.1,
        height_shift_range=0.1,
        shear_range=0.1,
        zoom_range=0.1,
        horizontal_flip=True,
        fill_mode='nearest',
        validation_split=0.2  # 20% for validation
    )
    
    # Only rescaling for validation
    validation_datagen = ImageDataGenerator(
        rescale=1./255,
        validation_split=0.2
    )
    
    # Define data directories
    data_dir = '/home/ubuntu/driver_drowsiness_detection/data/train'
    
    # Prepare eye state generators (Open/Closed)
    train_generator_eyes = train_datagen.flow_from_directory(
        data_dir,
        target_size=(IMG_SIZE, IMG_SIZE),
        batch_size=BATCH_SIZE,
        class_mode='categorical',
        color_mode='grayscale',
        classes=['Closed', 'Open'],
        subset='training',
        shuffle=True
    )
    
    validation_generator_eyes = validation_datagen.flow_from_directory(
        data_dir,
        target_size=(IMG_SIZE, IMG_SIZE),
        batch_size=BATCH_SIZE,
        class_mode='categorical',
        color_mode='grayscale',
        classes=['Closed', 'Open'],
        subset='validation',
        shuffle=False
    )
    
    # Prepare yawn detection generators (yawn/no_yawn)
    train_generator_yawn = train_datagen.flow_from_directory(
        data_dir,
        target_size=(IMG_SIZE, IMG_SIZE),
        batch_size=BATCH_SIZE,
        class_mode='categorical',
        color_mode='grayscale',
        classes=['no_yawn', 'yawn'],
        subset='training',
        shuffle=True
    )
    
    validation_generator_yawn = validation_datagen.flow_from_directory(
        data_dir,
        target_size=(IMG_SIZE, IMG_SIZE),
        batch_size=BATCH_SIZE,
        class_mode='categorical',
        color_mode='grayscale',
        classes=['no_yawn', 'yawn'],
        subset='validation',
        shuffle=False
    )
    
    return train_generator_eyes, validation_generator_eyes, train_generator_yawn, validation_generator_yawn

def setup_callbacks(model_name):
    """
    Set up callbacks for model training
    
    Parameters:
    -----------
    model_name : str
        Name of the model (e.g., 'eye_model', 'yawn_model')
    
    Returns:
    --------
    callbacks : list
        List of callbacks for model training
    """
    # Create models directory if it doesn't exist
    models_dir = '/home/ubuntu/driver_drowsiness_detection/models'
    os.makedirs(models_dir, exist_ok=True)
    
    # Define callbacks
    checkpoint = ModelCheckpoint(
        filepath=os.path.join(models_dir, f'{model_name}_best.h5'),
        monitor='val_accuracy',
        mode='max',
        save_best_only=True,
        verbose=1
    )
    
    early_stopping = EarlyStopping(
        monitor='val_accuracy',
        patience=5,
        restore_best_weights=True,
        verbose=1
    )
    
    reduce_lr = ReduceLROnPlateau(
        monitor='val_loss',
        factor=0.2,
        patience=3,
        min_lr=0.00001,
        verbose=1
    )
    
    return [checkpoint, early_stopping, reduce_lr]

def plot_training_history(history, model_name):
    """
    Plot training history
    
    Parameters:
    -----------
    history : tf.keras.callbacks.History
        Training history
    model_name : str
        Name of the model (e.g., 'eye_model', 'yawn_model')
    """
    # Create plots directory if it doesn't exist
    plots_dir = '/home/ubuntu/driver_drowsiness_detection/logs'
    os.makedirs(plots_dir, exist_ok=True)
    
    # Plot accuracy
    plt.figure(figsize=(12, 4))
    
    plt.subplot(1, 2, 1)
    plt.plot(history.history['accuracy'])
    plt.plot(history.history['val_accuracy'])
    plt.title(f'{model_name} - Accuracy')
    plt.ylabel('Accuracy')
    plt.xlabel('Epoch')
    plt.legend(['Train', 'Validation'], loc='upper left')
    
    # Plot loss
    plt.subplot(1, 2, 2)
    plt.plot(history.history['loss'])
    plt.plot(history.history['val_loss'])
    plt.title(f'{model_name} - Loss')
    plt.ylabel('Loss')
    plt.xlabel('Epoch')
    plt.legend(['Train', 'Validation'], loc='upper left')
    
    plt.tight_layout()
    plt.savefig(os.path.join(plots_dir, f'{model_name}_training_history.png'))
    plt.close()

def model_summary():
    """
    Print model summaries
    """
    # Create eye model and print summary
    eye_model = create_eye_model()
    print("Eye State Classification Model Summary:")
    eye_model.summary()
    
    # Create yawn model and print summary
    yawn_model = create_yawn_model()
    print("\nYawn Detection Model Summary:")
    yawn_model.summary()

if __name__ == "__main__":
    # Print model summaries
    model_summary()
