import os
import numpy as np
import tensorflow as tf
from tensorflow.keras.models import Sequential, Model
from tensorflow.keras.layers import Conv2D, MaxPooling2D, Dropout, Flatten, Dense, BatchNormalization
from tensorflow.keras.layers import Input, GlobalAveragePooling2D, Concatenate
from tensorflow.keras.optimizers import Adam
from tensorflow.keras.callbacks import ModelCheckpoint, EarlyStopping, ReduceLROnPlateau
import matplotlib.pyplot as plt

# Define constants
IMG_SIZE = 224
DATA_DIR = '/home/ubuntu/driver_drowsiness_detection/data'
PROCESSED_DIR = os.path.join(DATA_DIR, 'processed')
FEATURES_DIR = os.path.join(DATA_DIR, 'features')
MODELS_DIR = '/home/ubuntu/driver_drowsiness_detection/models'
LOGS_DIR = '/home/ubuntu/driver_drowsiness_detection/logs'

# Create directories if they don't exist
os.makedirs(MODELS_DIR, exist_ok=True)
os.makedirs(LOGS_DIR, exist_ok=True)

def create_custom_cnn_model(input_shape=(IMG_SIZE, IMG_SIZE, 1), num_classes=2):
    """
    Create a custom CNN model for drowsiness detection
    
    Parameters:
    -----------
    input_shape : tuple
        Input shape of the model
    num_classes : int
        Number of output classes
        
    Returns:
    --------
    model : tensorflow.keras.Model
        Compiled model
    """
    model = Sequential([
        # First convolutional block
        Conv2D(32, (3, 3), activation='relu', padding='same', input_shape=input_shape),
        BatchNormalization(),
        Conv2D(32, (3, 3), activation='relu', padding='same'),
        BatchNormalization(),
        MaxPooling2D(pool_size=(2, 2)),
        Dropout(0.25),
        
        # Second convolutional block
        Conv2D(64, (3, 3), activation='relu', padding='same'),
        BatchNormalization(),
        Conv2D(64, (3, 3), activation='relu', padding='same'),
        BatchNormalization(),
        MaxPooling2D(pool_size=(2, 2)),
        Dropout(0.25),
        
        # Third convolutional block
        Conv2D(128, (3, 3), activation='relu', padding='same'),
        BatchNormalization(),
        Conv2D(128, (3, 3), activation='relu', padding='same'),
        BatchNormalization(),
        MaxPooling2D(pool_size=(2, 2)),
        Dropout(0.25),
        
        # Fully connected layers
        Flatten(),
        Dense(512, activation='relu'),
        BatchNormalization(),
        Dropout(0.5),
        Dense(num_classes, activation='softmax')
    ])
    
    # Compile model
    model.compile(
        optimizer=Adam(learning_rate=0.001),
        loss='categorical_crossentropy',
        metrics=['accuracy']
    )
    
    return model

def create_hybrid_model(feature_shape, num_classes=2):
    """
    Create a hybrid model that uses extracted features
    
    Parameters:
    -----------
    feature_shape : tuple
        Shape of the extracted features
    num_classes : int
        Number of output classes
        
    Returns:
    --------
    model : tensorflow.keras.Model
        Compiled model
    """
    # Input layer
    inputs = Input(shape=feature_shape)
    
    # Dense layers
    x = Dense(512, activation='relu')(inputs)
    x = BatchNormalization()(x)
    x = Dropout(0.5)(x)
    
    x = Dense(256, activation='relu')(x)
    x = BatchNormalization()(x)
    x = Dropout(0.5)(x)
    
    # Output layer
    outputs = Dense(num_classes, activation='softmax')(x)
    
    # Create model
    model = Model(inputs=inputs, outputs=outputs)
    
    # Compile model
    model.compile(
        optimizer=Adam(learning_rate=0.001),
        loss='categorical_crossentropy',
        metrics=['accuracy']
    )
    
    return model

def create_ensemble_model(input_shape=(IMG_SIZE, IMG_SIZE, 1), num_classes=2):
    """
    Create an ensemble model that combines multiple approaches
    
    Parameters:
    -----------
    input_shape : tuple
        Input shape of the model
    num_classes : int
        Number of output classes
        
    Returns:
    --------
    model : tensorflow.keras.Model
        Compiled model
    """
    # Input layer
    inputs = Input(shape=input_shape)
    
    # Path 1: Standard CNN
    x1 = Conv2D(32, (3, 3), activation='relu', padding='same')(inputs)
    x1 = BatchNormalization()(x1)
    x1 = MaxPooling2D(pool_size=(2, 2))(x1)
    
    x1 = Conv2D(64, (3, 3), activation='relu', padding='same')(x1)
    x1 = BatchNormalization()(x1)
    x1 = MaxPooling2D(pool_size=(2, 2))(x1)
    
    x1 = Conv2D(128, (3, 3), activation='relu', padding='same')(x1)
    x1 = BatchNormalization()(x1)
    x1 = GlobalAveragePooling2D()(x1)
    
    # Path 2: Deeper CNN with different filter sizes
    x2 = Conv2D(32, (5, 5), activation='relu', padding='same')(inputs)
    x2 = BatchNormalization()(x2)
    x2 = MaxPooling2D(pool_size=(2, 2))(x2)
    
    x2 = Conv2D(64, (5, 5), activation='relu', padding='same')(x2)
    x2 = BatchNormalization()(x2)
    x2 = MaxPooling2D(pool_size=(2, 2))(x2)
    
    x2 = Conv2D(128, (5, 5), activation='relu', padding='same')(x2)
    x2 = BatchNormalization()(x2)
    x2 = GlobalAveragePooling2D()(x2)
    
    # Path 3: CNN with smaller filters for fine details
    x3 = Conv2D(32, (1, 1), activation='relu', padding='same')(inputs)
    x3 = Conv2D(48, (3, 3), activation='relu', padding='same')(x3)
    x3 = BatchNormalization()(x3)
    x3 = MaxPooling2D(pool_size=(2, 2))(x3)
    
    x3 = Conv2D(64, (1, 1), activation='relu', padding='same')(x3)
    x3 = Conv2D(96, (3, 3), activation='relu', padding='same')(x3)
    x3 = BatchNormalization()(x3)
    x3 = MaxPooling2D(pool_size=(2, 2))(x3)
    
    x3 = Conv2D(128, (1, 1), activation='relu', padding='same')(x3)
    x3 = Conv2D(192, (3, 3), activation='relu', padding='same')(x3)
    x3 = BatchNormalization()(x3)
    x3 = GlobalAveragePooling2D()(x3)
    
    # Combine paths
    combined = Concatenate()([x1, x2, x3])
    
    # Fully connected layers
    x = Dense(512, activation='relu')(combined)
    x = BatchNormalization()(x)
    x = Dropout(0.5)(x)
    
    # Output layer
    outputs = Dense(num_classes, activation='softmax')(x)
    
    # Create model
    model = Model(inputs=inputs, outputs=outputs)
    
    # Compile model
    model.compile(
        optimizer=Adam(learning_rate=0.0005),  # Lower learning rate for complex model
        loss='categorical_crossentropy',
        metrics=['accuracy']
    )
    
    return model

def setup_callbacks(model_name):
    """
    Set up training callbacks
    
    Parameters:
    -----------
    model_name : str
        Name of the model for saving checkpoints
        
    Returns:
    --------
    callbacks : list
        List of callbacks
    """
    # Model checkpoint to save best model
    checkpoint = ModelCheckpoint(
        os.path.join(MODELS_DIR, f"{model_name}_best.h5"),
        monitor='val_accuracy',
        save_best_only=True,
        mode='max',
        verbose=1
    )
    
    # Early stopping to prevent overfitting
    early_stopping = EarlyStopping(
        monitor='val_accuracy',
        patience=10,
        restore_best_weights=True,
        mode='max',
        verbose=1
    )
    
    # Reduce learning rate when plateau is reached
    reduce_lr = ReduceLROnPlateau(
        monitor='val_accuracy',
        factor=0.2,
        patience=5,
        min_lr=1e-6,
        mode='max',
        verbose=1
    )
    
    return [checkpoint, early_stopping, reduce_lr]

def plot_training_history(history, model_name):
    """
    Plot training history
    
    Parameters:
    -----------
    history : tensorflow.keras.callbacks.History
        Training history
    model_name : str
        Name of the model for saving plots
    """
    # Plot accuracy
    plt.figure(figsize=(12, 5))
    
    plt.subplot(1, 2, 1)
    plt.plot(history.history['accuracy'], label='Training Accuracy')
    plt.plot(history.history['val_accuracy'], label='Validation Accuracy')
    plt.title('Model Accuracy')
    plt.xlabel('Epoch')
    plt.ylabel('Accuracy')
    plt.legend()
    plt.grid(True, alpha=0.3)
    
    # Plot loss
    plt.subplot(1, 2, 2)
    plt.plot(history.history['loss'], label='Training Loss')
    plt.plot(history.history['val_loss'], label='Validation Loss')
    plt.title('Model Loss')
    plt.xlabel('Epoch')
    plt.ylabel('Loss')
    plt.legend()
    plt.grid(True, alpha=0.3)
    
    plt.tight_layout()
    plt.savefig(os.path.join(LOGS_DIR, f"{model_name}_training_history.png"))
    plt.close()

if __name__ == "__main__":
    # Create and display model summaries
    print("Creating model architectures...")
    
    # Custom CNN model for eye state classification
    eye_model = create_custom_cnn_model(input_shape=(IMG_SIZE, IMG_SIZE, 1), num_classes=2)
    print("\nEye State Classification Model:")
    eye_model.summary()
    
    # Custom CNN model for yawn detection
    yawn_model = create_custom_cnn_model(input_shape=(IMG_SIZE, IMG_SIZE, 1), num_classes=2)
    print("\nYawn Detection Model:")
    yawn_model.summary()
    
    # Ensemble model for improved performance
    ensemble_model = create_ensemble_model(input_shape=(IMG_SIZE, IMG_SIZE, 1), num_classes=2)
    print("\nEnsemble Model:")
    ensemble_model.summary()
    
    print("\nModel architectures created successfully!")
