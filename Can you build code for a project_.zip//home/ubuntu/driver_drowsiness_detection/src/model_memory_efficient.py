import os
import numpy as np
import tensorflow as tf
from tensorflow.keras.models import Sequential, Model
from tensorflow.keras.layers import Conv2D, MaxPooling2D, Dropout, Flatten, Dense, BatchNormalization
from tensorflow.keras.layers import Input, GlobalAveragePooling2D, Concatenate
from tensorflow.keras.optimizers import Adam
from tensorflow.keras.callbacks import ModelCheckpoint, EarlyStopping, ReduceLROnPlateau
import matplotlib.pyplot as plt

# Define constants with memory-efficient settings
IMG_SIZE = 128  # Reduced from 224 to save memory
BATCH_SIZE = 16  # Reduced from 32 to save memory
EPOCHS = 30
DATA_DIR = '/home/ubuntu/driver_drowsiness_detection/data'
PROCESSED_DIR = os.path.join(DATA_DIR, 'processed')
FEATURES_DIR = os.path.join(DATA_DIR, 'features')
MODELS_DIR = '/home/ubuntu/driver_drowsiness_detection/models'
LOGS_DIR = '/home/ubuntu/driver_drowsiness_detection/logs'

# Create directories if they don't exist
os.makedirs(MODELS_DIR, exist_ok=True)
os.makedirs(LOGS_DIR, exist_ok=True)

def create_memory_efficient_model(input_shape=(IMG_SIZE, IMG_SIZE, 1), num_classes=2):
    """
    Create a memory-efficient CNN model for drowsiness detection
    
    Parameters:
    -----------
    input_shape : tuple
        Input shape of the model
    num_classes : int
        Number of output classes
        
    Returns:
    --------
    model : tensorflow.keras.Model
        Compiled model
    """
    model = Sequential([
        # First convolutional block - reduced filters
        Conv2D(16, (3, 3), activation='relu', padding='same', input_shape=input_shape),
        BatchNormalization(),
        MaxPooling2D(pool_size=(2, 2)),
        Dropout(0.25),
        
        # Second convolutional block - reduced filters
        Conv2D(32, (3, 3), activation='relu', padding='same'),
        BatchNormalization(),
        MaxPooling2D(pool_size=(2, 2)),
        Dropout(0.25),
        
        # Third convolutional block - reduced filters
        Conv2D(64, (3, 3), activation='relu', padding='same'),
        BatchNormalization(),
        MaxPooling2D(pool_size=(2, 2)),
        Dropout(0.25),
        
        # Fully connected layers - reduced neurons
        Flatten(),
        Dense(128, activation='relu'),
        BatchNormalization(),
        Dropout(0.5),
        Dense(num_classes, activation='softmax')
    ])
    
    # Compile model
    model.compile(
        optimizer=Adam(learning_rate=0.001),
        loss='categorical_crossentropy',
        metrics=['accuracy']
    )
    
    return model

def create_lightweight_ensemble_model(input_shape=(IMG_SIZE, IMG_SIZE, 1), num_classes=2):
    """
    Create a lightweight ensemble model that uses less memory
    
    Parameters:
    -----------
    input_shape : tuple
        Input shape of the model
    num_classes : int
        Number of output classes
        
    Returns:
    --------
    model : tensorflow.keras.Model
        Compiled model
    """
    # Input layer
    inputs = Input(shape=input_shape)
    
    # Path 1: Standard CNN with reduced filters
    x1 = Conv2D(16, (3, 3), activation='relu', padding='same')(inputs)
    x1 = BatchNormalization()(x1)
    x1 = MaxPooling2D(pool_size=(2, 2))(x1)
    
    x1 = Conv2D(32, (3, 3), activation='relu', padding='same')(x1)
    x1 = BatchNormalization()(x1)
    x1 = GlobalAveragePooling2D()(x1)
    
    # Path 2: CNN with different filter sizes
    x2 = Conv2D(16, (5, 5), activation='relu', padding='same')(inputs)
    x2 = BatchNormalization()(x2)
    x2 = MaxPooling2D(pool_size=(2, 2))(x2)
    
    x2 = Conv2D(32, (5, 5), activation='relu', padding='same')(x2)
    x2 = BatchNormalization()(x2)
    x2 = GlobalAveragePooling2D()(x2)
    
    # Combine paths
    combined = Concatenate()([x1, x2])
    
    # Fully connected layers
    x = Dense(128, activation='relu')(combined)
    x = BatchNormalization()(x)
    x = Dropout(0.5)(x)
    
    # Output layer
    outputs = Dense(num_classes, activation='softmax')(x)
    
    # Create model
    model = Model(inputs=inputs, outputs=outputs)
    
    # Compile model
    model.compile(
        optimizer=Adam(learning_rate=0.001),
        loss='categorical_crossentropy',
        metrics=['accuracy']
    )
    
    return model

def setup_callbacks(model_name):
    """
    Set up training callbacks
    
    Parameters:
    -----------
    model_name : str
        Name of the model for saving checkpoints
        
    Returns:
    --------
    callbacks : list
        List of callbacks
    """
    # Model checkpoint to save best model
    checkpoint = ModelCheckpoint(
        os.path.join(MODELS_DIR, f"{model_name}_best.h5"),
        monitor='val_accuracy',
        save_best_only=True,
        mode='max',
        verbose=1
    )
    
    # Early stopping to prevent overfitting
    early_stopping = EarlyStopping(
        monitor='val_accuracy',
        patience=10,
        restore_best_weights=True,
        mode='max',
        verbose=1
    )
    
    # Reduce learning rate when plateau is reached
    reduce_lr = ReduceLROnPlateau(
        monitor='val_accuracy',
        factor=0.2,
        patience=5,
        min_lr=1e-6,
        mode='max',
        verbose=1
    )
    
    return [checkpoint, early_stopping, reduce_lr]

def plot_training_history(history, model_name):
    """
    Plot training history
    
    Parameters:
    -----------
    history : tensorflow.keras.callbacks.History
        Training history
    model_name : str
        Name of the model for saving plots
    """
    # Plot accuracy
    plt.figure(figsize=(12, 5))
    
    plt.subplot(1, 2, 1)
    plt.plot(history.history['accuracy'], label='Training Accuracy')
    plt.plot(history.history['val_accuracy'], label='Validation Accuracy')
    plt.title('Model Accuracy')
    plt.xlabel('Epoch')
    plt.ylabel('Accuracy')
    plt.legend()
    plt.grid(True, alpha=0.3)
    
    # Plot loss
    plt.subplot(1, 2, 2)
    plt.plot(history.history['loss'], label='Training Loss')
    plt.plot(history.history['val_loss'], label='Validation Loss')
    plt.title('Model Loss')
    plt.xlabel('Epoch')
    plt.ylabel('Loss')
    plt.legend()
    plt.grid(True, alpha=0.3)
    
    plt.tight_layout()
    plt.savefig(os.path.join(LOGS_DIR, f"{model_name}_training_history.png"))
    plt.close()

if __name__ == "__main__":
    # Create and display model summaries
    print("Creating memory-efficient model architectures...")
    
    # Memory-efficient model for eye state classification
    eye_model = create_memory_efficient_model(input_shape=(IMG_SIZE, IMG_SIZE, 1), num_classes=2)
    print("\nMemory-Efficient Eye State Classification Model:")
    eye_model.summary()
    
    # Memory-efficient model for yawn detection
    yawn_model = create_memory_efficient_model(input_shape=(IMG_SIZE, IMG_SIZE, 1), num_classes=2)
    print("\nMemory-Efficient Yawn Detection Model:")
    yawn_model.summary()
    
    # Lightweight ensemble model
    ensemble_model = create_lightweight_ensemble_model(input_shape=(IMG_SIZE, IMG_SIZE, 1), num_classes=2)
    print("\nLightweight Ensemble Model:")
    ensemble_model.summary()
    
    print("\nMemory-efficient model architectures created successfully!")
