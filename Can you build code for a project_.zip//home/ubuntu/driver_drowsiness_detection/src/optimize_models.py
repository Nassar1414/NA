import os
import tensorflow as tf
import numpy as np
import cv2
from tensorflow.keras.models import load_model, Model
from tensorflow.keras.layers import Input
import time

# Define constants
IMG_SIZE = 224
MODELS_DIR = '/home/ubuntu/driver_drowsiness_detection/models'
OPTIMIZED_MODELS_DIR = '/home/ubuntu/driver_drowsiness_detection/optimized_models'

# Create directories if they don't exist
os.makedirs(OPTIMIZED_MODELS_DIR, exist_ok=True)

def optimize_model_for_inference(model_path, optimized_model_name):
    """
    Optimize a model for inference by converting to TensorFlow Lite format
    
    Parameters:
    -----------
    model_path : str
        Path to the original model
    optimized_model_name : str
        Name for the optimized model
        
    Returns:
    --------
    tflite_model_path : str
        Path to the optimized TFLite model
    """
    print(f"Optimizing model: {model_path}")
    
    # Load the model
    model = load_model(model_path)
    
    # Convert to TensorFlow Lite model
    converter = tf.lite.TFLiteConverter.from_keras_model(model)
    
    # Enable optimizations
    converter.optimizations = [tf.lite.Optimize.DEFAULT]
    
    # Quantize weights to 8-bit
    converter.target_spec.supported_ops = [tf.lite.OpsSet.TFLITE_BUILTINS_INT8]
    converter.inference_input_type = tf.uint8
    converter.inference_output_type = tf.uint8
    
    # Representative dataset for quantization
    def representative_dataset():
        for _ in range(100):
            data = np.random.rand(1, IMG_SIZE, IMG_SIZE, 1) * 255
            data = data.astype(np.float32)
            yield [data]
    
    converter.representative_dataset = representative_dataset
    
    # Convert the model
    tflite_model = converter.convert()
    
    # Save the model
    tflite_model_path = os.path.join(OPTIMIZED_MODELS_DIR, f"{optimized_model_name}.tflite")
    with open(tflite_model_path, 'wb') as f:
        f.write(tflite_model)
    
    print(f"Optimized model saved to: {tflite_model_path}")
    
    return tflite_model_path

def optimize_model_for_web(model_path, optimized_model_name):
    """
    Optimize a model for web deployment by converting to TensorFlow.js format
    
    Parameters:
    -----------
    model_path : str
        Path to the original model
    optimized_model_name : str
        Name for the optimized model
        
    Returns:
    --------
    tfjs_model_dir : str
        Directory containing the optimized TensorFlow.js model
    """
    print(f"Optimizing model for web: {model_path}")
    
    # Create output directory
    tfjs_model_dir = os.path.join(OPTIMIZED_MODELS_DIR, f"{optimized_model_name}_tfjs")
    os.makedirs(tfjs_model_dir, exist_ok=True)
    
    try:
        # Check if tensorflowjs_converter is installed
        import subprocess
        result = subprocess.run(['tensorflowjs_converter', '--version'], 
                               stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        
        # Convert model to TensorFlow.js format
        cmd = [
            'tensorflowjs_converter',
            '--input_format=keras',
            f'--output_node_names=dense',
            '--quantize_float16=*',
            model_path,
            tfjs_model_dir
        ]
        
        subprocess.run(cmd, check=True)
        print(f"Model optimized for web and saved to: {tfjs_model_dir}")
        
    except Exception as e:
        print(f"Error optimizing model for web: {e}")
        print("Please install TensorFlow.js converter: pip install tensorflowjs")
        
        # Create a placeholder file to indicate conversion was attempted
        with open(os.path.join(tfjs_model_dir, 'conversion_failed.txt'), 'w') as f:
            f.write(f"Conversion failed: {e}\n")
            f.write("Please install TensorFlow.js converter: pip install tensorflowjs\n")
    
    return tfjs_model_dir

def benchmark_model_performance(model_path):
    """
    Benchmark model performance for inference
    
    Parameters:
    -----------
    model_path : str
        Path to the model
        
    Returns:
    --------
    avg_inference_time : float
        Average inference time in milliseconds
    """
    print(f"Benchmarking model: {model_path}")
    
    # Load the model
    model = load_model(model_path)
    
    # Warm up
    for _ in range(10):
        dummy_input = np.random.rand(1, IMG_SIZE, IMG_SIZE, 1).astype(np.float32)
        _ = model.predict(dummy_input, verbose=0)
    
    # Benchmark
    num_runs = 100
    inference_times = []
    
    for _ in range(num_runs):
        dummy_input = np.random.rand(1, IMG_SIZE, IMG_SIZE, 1).astype(np.float32)
        
        start_time = time.time()
        _ = model.predict(dummy_input, verbose=0)
        end_time = time.time()
        
        inference_time = (end_time - start_time) * 1000  # Convert to milliseconds
        inference_times.append(inference_time)
    
    avg_inference_time = sum(inference_times) / len(inference_times)
    print(f"Average inference time: {avg_inference_time:.2f} ms")
    
    return avg_inference_time

def optimize_all_models():
    """Optimize all available models"""
    print("Optimizing all models...")
    
    # Find all models
    model_files = [f for f in os.listdir(MODELS_DIR) if f.endswith('.h5')]
    
    if not model_files:
        print("No models found in", MODELS_DIR)
        return
    
    results = []
    
    for model_file in model_files:
        model_path = os.path.join(MODELS_DIR, model_file)
        model_name = os.path.splitext(model_file)[0]
        
        print(f"\nProcessing model: {model_name}")
        
        # Benchmark original model
        original_inference_time = benchmark_model_performance(model_path)
        
        # Optimize for inference (TFLite)
        tflite_path = optimize_model_for_inference(model_path, model_name)
        
        # Optimize for web (TensorFlow.js)
        tfjs_dir = optimize_model_for_web(model_path, model_name)
        
        # Store results
        results.append({
            'model_name': model_name,
            'original_path': model_path,
            'original_inference_time': original_inference_time,
            'tflite_path': tflite_path,
            'tfjs_dir': tfjs_dir
        })
    
    # Print summary
    print("\nOptimization Summary:")
    print("=" * 80)
    print(f"{'Model Name':<30} {'Original Inference Time (ms)':<30}")
    print("-" * 80)
    
    for result in results:
        print(f"{result['model_name']:<30} {result['original_inference_time']:.2f} ms")
    
    print("\nOptimized models saved to:", OPTIMIZED_MODELS_DIR)

if __name__ == "__main__":
    optimize_all_models()
