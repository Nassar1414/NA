import os
import numpy as np
import cv2
import matplotlib.pyplot as plt
from tqdm import tqdm
from sklearn.model_selection import train_test_split

# Define constants
IMG_SIZE = 224  # Standard size for many pre-trained models
DATA_DIR = '/home/ubuntu/driver_drowsiness_detection/data'
TRAIN_DIR = os.path.join(DATA_DIR, 'train')
PROCESSED_DIR = os.path.join(DATA_DIR, 'processed')
CATEGORIES = ['Closed', 'Open', 'no_yawn', 'yawn']

def create_directories():
    """Create necessary directories for processed data"""
    os.makedirs(PROCESSED_DIR, exist_ok=True)
    
    # Create directories for each category and split
    for split in ['train', 'val', 'test']:
        split_dir = os.path.join(PROCESSED_DIR, split)
        os.makedirs(split_dir, exist_ok=True)
        
        for category in CATEGORIES:
            os.makedirs(os.path.join(split_dir, category), exist_ok=True)

def preprocess_image(image_path):
    """
    Preprocess a single image
    
    Parameters:
    -----------
    image_path : str
        Path to the image file
        
    Returns:
    --------
    processed_img : numpy.ndarray
        Preprocessed image
    """
    # Read image
    img = cv2.imread(image_path)
    
    if img is None:
        return None
    
    # Convert to grayscale
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    
    # Resize to standard size
    resized = cv2.resize(gray, (IMG_SIZE, IMG_SIZE))
    
    # Apply histogram equalization for better contrast
    equalized = cv2.equalizeHist(resized)
    
    # Normalize pixel values to [0, 1]
    normalized = equalized / 255.0
    
    # Expand dimensions to match model input shape (add channel dimension)
    processed_img = np.expand_dims(normalized, axis=-1)
    
    return processed_img

def process_dataset():
    """Process the entire dataset and split into train/val/test sets"""
    print("Processing dataset...")
    
    # Create directories
    create_directories()
    
    # Process each category
    for category in CATEGORIES:
        print(f"Processing {category} images...")
        category_path = os.path.join(TRAIN_DIR, category)
        
        if not os.path.exists(category_path):
            print(f"Warning: Category path {category_path} does not exist")
            continue
        
        # Get all image files
        image_files = [f for f in os.listdir(category_path) if f.endswith(('.jpg', '.jpeg', '.png'))]
        
        # Split into train (70%), validation (15%), and test (15%)
        train_files, temp_files = train_test_split(image_files, test_size=0.3, random_state=42)
        val_files, test_files = train_test_split(temp_files, test_size=0.5, random_state=42)
        
        print(f"  Train: {len(train_files)}, Validation: {len(val_files)}, Test: {len(test_files)}")
        
        # Process and save images for each split
        for split_name, files in [('train', train_files), ('val', val_files), ('test', test_files)]:
            split_dir = os.path.join(PROCESSED_DIR, split_name, category)
            
            for file in tqdm(files, desc=f"  Processing {split_name}"):
                # Preprocess image
                image_path = os.path.join(category_path, file)
                processed_img = preprocess_image(image_path)
                
                if processed_img is not None:
                    # Save processed image
                    output_path = os.path.join(split_dir, file.replace('.jpg', '.npy').replace('.jpeg', '.npy').replace('.png', '.npy'))
                    np.save(output_path, processed_img)

def visualize_processed_images():
    """Visualize sample processed images from each category"""
    print("Visualizing processed images...")
    
    plt.figure(figsize=(15, 10))
    
    for i, category in enumerate(CATEGORIES):
        category_path = os.path.join(PROCESSED_DIR, 'train', category)
        
        if not os.path.exists(category_path):
            continue
        
        # Get all processed files
        processed_files = [f for f in os.listdir(category_path) if f.endswith('.npy')]
        
        if not processed_files:
            continue
        
        # Sample up to 5 files
        sample_size = min(5, len(processed_files))
        sampled_files = np.random.choice(processed_files, sample_size, replace=False)
        
        for j, file in enumerate(sampled_files):
            # Load processed image
            processed_img = np.load(os.path.join(category_path, file))
            
            # Plot image
            plt.subplot(len(CATEGORIES), sample_size, i*sample_size + j + 1)
            plt.imshow(processed_img.squeeze(), cmap='gray')
            plt.title(f"{category}")
            plt.axis('off')
    
    plt.tight_layout()
    plt.savefig(os.path.join(DATA_DIR, 'processed_samples.png'))
    plt.close()

def create_metadata():
    """Create metadata file with dataset information"""
    print("Creating metadata file...")
    
    metadata = {
        'image_size': IMG_SIZE,
        'categories': CATEGORIES,
        'counts': {}
    }
    
    # Count processed images in each split and category
    for split in ['train', 'val', 'test']:
        metadata['counts'][split] = {}
        
        for category in CATEGORIES:
            category_path = os.path.join(PROCESSED_DIR, split, category)
            
            if os.path.exists(category_path):
                processed_files = [f for f in os.listdir(category_path) if f.endswith('.npy')]
                metadata['counts'][split][category] = len(processed_files)
            else:
                metadata['counts'][split][category] = 0
    
    # Save metadata
    with open(os.path.join(PROCESSED_DIR, 'metadata.txt'), 'w') as f:
        f.write("Driver Drowsiness Detection - Dataset Metadata\n")
        f.write("===========================================\n\n")
        
        f.write(f"Image Size: {metadata['image_size']}x{metadata['image_size']}\n")
        f.write(f"Categories: {', '.join(metadata['categories'])}\n\n")
        
        f.write("Image Counts:\n")
        for split, counts in metadata['counts'].items():
            f.write(f"  {split.capitalize()}:\n")
            for category, count in counts.items():
                f.write(f"    {category}: {count}\n")
            
            # Calculate total
            total = sum(counts.values())
            f.write(f"    Total: {total}\n\n")
        
        # Calculate grand total
        grand_total = sum(sum(counts.values()) for counts in metadata['counts'].values())
        f.write(f"Grand Total: {grand_total}\n")

if __name__ == "__main__":
    # Process dataset
    process_dataset()
    
    # Visualize processed images
    visualize_processed_images()
    
    # Create metadata
    create_metadata()
    
    print("Data preprocessing complete!")
