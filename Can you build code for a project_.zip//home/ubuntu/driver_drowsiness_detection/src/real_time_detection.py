import os
import numpy as np
import cv2
import tensorflow as tf
from tensorflow.keras.models import load_model
import time
import pygame

# Define constants
IMG_SIZE = 224
MODELS_DIR = '/home/ubuntu/driver_drowsiness_detection/models'
SOUND_DIR = '/home/ubuntu/driver_drowsiness_detection/sounds'

# Create directories if they don't exist
os.makedirs(SOUND_DIR, exist_ok=True)

# Initialize pygame for sound alerts
pygame.mixer.init()

class DrowsinessDetector:
    def __init__(self, eye_model_path=None, yawn_model_path=None):
        """
        Initialize the drowsiness detector
        
        Parameters:
        -----------
        eye_model_path : str
            Path to the eye state classification model
        yawn_model_path : str
            Path to the yawn detection model
        """
        # Load face and eye cascade classifiers
        self.face_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + 'haarcascade_frontalface_default.xml')
        self.eye_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + 'haarcascade_eye.xml')
        
        # Load models
        if eye_model_path and os.path.exists(eye_model_path):
            self.eye_model = load_model(eye_model_path)
            print(f"Loaded eye model from {eye_model_path}")
        else:
            # Use default model path
            default_eye_path = os.path.join(MODELS_DIR, 'eye_ensemble_best.h5')
            if os.path.exists(default_eye_path):
                self.eye_model = load_model(default_eye_path)
                print(f"Loaded eye model from {default_eye_path}")
            else:
                print("Warning: No eye model found. Please train the model first.")
                self.eye_model = None
        
        if yawn_model_path and os.path.exists(yawn_model_path):
            self.yawn_model = load_model(yawn_model_path)
            print(f"Loaded yawn model from {yawn_model_path}")
        else:
            # Use default model path
            default_yawn_path = os.path.join(MODELS_DIR, 'yawn_ensemble_best.h5')
            if os.path.exists(default_yawn_path):
                self.yawn_model = load_model(default_yawn_path)
                print(f"Loaded yawn model from {default_yawn_path}")
            else:
                print("Warning: No yawn model found. Please train the model first.")
                self.yawn_model = None
        
        # Initialize counters and states
        self.eye_closure_counter = 0
        self.yawn_counter = 0
        self.alert_active = False
        self.last_alert_time = 0
        
        # Prepare alert sound
        self.alert_sound_path = os.path.join(SOUND_DIR, 'alert.wav')
        if not os.path.exists(self.alert_sound_path):
            self._generate_alert_sound()
    
    def _generate_alert_sound(self):
        """Generate a simple alert sound using pygame"""
        try:
            import numpy as np
            from scipy.io.wavfile import write
            
            # Generate a simple beep sound
            sample_rate = 44100
            duration = 1.0  # seconds
            frequency = 440  # Hz (A4)
            
            t = np.linspace(0, duration, int(sample_rate * duration), False)
            beep = np.sin(2 * np.pi * frequency * t) * 0.5
            
            # Add fade in/out
            fade_duration = 0.1  # seconds
            fade_samples = int(fade_duration * sample_rate)
            fade_in = np.linspace(0, 1, fade_samples)
            fade_out = np.linspace(1, 0, fade_samples)
            
            beep[:fade_samples] *= fade_in
            beep[-fade_samples:] *= fade_out
            
            # Convert to 16-bit PCM
            beep = (beep * 32767).astype(np.int16)
            
            # Save as WAV file
            write(self.alert_sound_path, sample_rate, beep)
            print(f"Generated alert sound at {self.alert_sound_path}")
        except Exception as e:
            print(f"Error generating alert sound: {e}")
            # Create an empty file to prevent repeated attempts
            with open(self.alert_sound_path, 'w') as f:
                pass
    
    def preprocess_eye_image(self, eye_img):
        """
        Preprocess eye image for model input
        
        Parameters:
        -----------
        eye_img : numpy.ndarray
            Eye image
            
        Returns:
        --------
        processed_img : numpy.ndarray
            Preprocessed image
        """
        # Convert to grayscale
        gray = cv2.cvtColor(eye_img, cv2.COLOR_BGR2GRAY)
        
        # Resize to standard size
        resized = cv2.resize(gray, (IMG_SIZE, IMG_SIZE))
        
        # Apply histogram equalization for better contrast
        equalized = cv2.equalizeHist(resized)
        
        # Normalize pixel values to [0, 1]
        normalized = equalized / 255.0
        
        # Expand dimensions to match model input shape
        processed_img = np.expand_dims(normalized, axis=-1)
        processed_img = np.expand_dims(processed_img, axis=0)
        
        return processed_img
    
    def detect_drowsiness(self, frame):
        """
        Detect drowsiness in a video frame
        
        Parameters:
        -----------
        frame : numpy.ndarray
            Video frame
            
        Returns:
        --------
        result_frame : numpy.ndarray
            Frame with detection results
        is_drowsy : bool
            Whether drowsiness is detected
        """
        # Convert to grayscale for face detection
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        
        # Detect faces
        faces = self.face_cascade.detectMultiScale(gray, 1.3, 5)
        
        # Initialize result
        is_drowsy = False
        
        # Process each face
        for (x, y, w, h) in faces:
            # Draw face rectangle
            cv2.rectangle(frame, (x, y), (x+w, y+h), (255, 0, 0), 2)
            
            # Extract face region
            face_gray = gray[y:y+h, x:x+w]
            face_color = frame[y:y+h, x:x+w]
            
            # Detect eyes
            eyes = self.eye_cascade.detectMultiScale(face_gray)
            
            # Process eyes if detected
            if len(eyes) > 0 and self.eye_model is not None:
                # Extract and process eye regions
                eye_states = []
                
                for (ex, ey, ew, eh) in eyes:
                    # Draw eye rectangle
                    cv2.rectangle(face_color, (ex, ey), (ex+ew, ey+eh), (0, 255, 0), 2)
                    
                    # Extract eye region
                    eye_img = face_color[ey:ey+eh, ex:ex+ew]
                    
                    # Preprocess eye image
                    processed_eye = self.preprocess_eye_image(eye_img)
                    
                    # Predict eye state
                    eye_pred = self.eye_model.predict(processed_eye, verbose=0)
                    eye_state = np.argmax(eye_pred)  # 0: Closed, 1: Open
                    eye_states.append(eye_state)
                    
                    # Display eye state
                    state_text = "Open" if eye_state == 1 else "Closed"
                    cv2.putText(face_color, state_text, (ex, ey-5), 
                                cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 2)
                
                # Check if all eyes are closed
                if all(state == 0 for state in eye_states):
                    self.eye_closure_counter += 1
                else:
                    self.eye_closure_counter = 0
            
            # Process face for yawn detection
            if self.yawn_model is not None:
                # Preprocess face image for yawn detection
                face_img = cv2.resize(face_color, (IMG_SIZE, IMG_SIZE))
                face_gray = cv2.cvtColor(face_img, cv2.COLOR_BGR2GRAY)
                face_equalized = cv2.equalizeHist(face_gray)
                face_normalized = face_equalized / 255.0
                face_processed = np.expand_dims(face_normalized, axis=-1)
                face_processed = np.expand_dims(face_processed, axis=0)
                
                # Predict yawn state
                yawn_pred = self.yawn_model.predict(face_processed, verbose=0)
                yawn_state = np.argmax(yawn_pred)  # 0: No Yawn, 1: Yawn
                
                # Display yawn state
                yawn_text = "Yawning" if yawn_state == 1 else "No Yawn"
                cv2.putText(frame, yawn_text, (x, y-10), 
                            cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 0, 255), 2)
                
                # Update yawn counter
                if yawn_state == 1:
                    self.yawn_counter += 1
                else:
                    self.yawn_counter = max(0, self.yawn_counter - 1)
        
        # Check drowsiness conditions
        if self.eye_closure_counter >= 15:  # Eyes closed for ~0.5 seconds (assuming 30 FPS)
            is_drowsy = True
            cv2.putText(frame, "DROWSINESS ALERT!", (10, 30), 
                        cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 0, 255), 2)
        
        if self.yawn_counter >= 10:  # Frequent yawning
            is_drowsy = True
            cv2.putText(frame, "DROWSINESS ALERT! (Yawning)", (10, 60), 
                        cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 0, 255), 2)
        
        # Display counters
        cv2.putText(frame, f"Eye Closure: {self.eye_closure_counter}", (10, 90), 
                    cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 2)
        cv2.putText(frame, f"Yawn Count: {self.yawn_counter}", (10, 120), 
                    cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 2)
        
        # Play alert if drowsy
        if is_drowsy:
            current_time = time.time()
            if not self.alert_active or (current_time - self.last_alert_time) > 3.0:
                self.alert_active = True
                self.last_alert_time = current_time
                try:
                    pygame.mixer.music.load(self.alert_sound_path)
                    pygame.mixer.music.play()
                except Exception as e:
                    print(f"Error playing alert sound: {e}")
        else:
            self.alert_active = False
        
        return frame, is_drowsy

def run_detection():
    """Run real-time drowsiness detection using webcam"""
    # Initialize detector
    detector = DrowsinessDetector()
    
    # Initialize webcam
    cap = cv2.VideoCapture(0)
    
    if not cap.isOpened():
        print("Error: Could not open webcam.")
        return
    
    print("Starting real-time drowsiness detection...")
    print("Press 'q' to quit.")
    
    while True:
        # Read frame
        ret, frame = cap.read()
        
        if not ret:
            print("Error: Failed to capture frame.")
            break
        
        # Detect drowsiness
        result_frame, is_drowsy = detector.detect_drowsiness(frame)
        
        # Display result
        cv2.imshow('Driver Drowsiness Detection', result_frame)
        
        # Check for quit key
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break
    
    # Release resources
    cap.release()
    cv2.destroyAllWindows()

if __name__ == "__main__":
    run_detection()
