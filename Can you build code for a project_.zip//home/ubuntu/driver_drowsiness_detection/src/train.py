import os
import numpy as np
import tensorflow as tf
from tensorflow.keras.preprocessing.image import ImageDataGenerator
from tensorflow.keras.callbacks import ModelCheckpoint, EarlyStopping, ReduceLROnPlateau
import matplotlib.pyplot as plt
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, confusion_matrix
import seaborn as sns
from model import create_eye_model, create_yawn_model, setup_callbacks, plot_training_history

# Define constants
IMG_SIZE = 64
BATCH_SIZE = 32
EPOCHS = 20
LEARNING_RATE = 0.001

# Define paths
DATA_DIR = '/home/ubuntu/driver_drowsiness_detection/data'
TRAIN_DIR = os.path.join(DATA_DIR, 'train')
MODELS_DIR = '/home/ubuntu/driver_drowsiness_detection/models'
LOGS_DIR = '/home/ubuntu/driver_drowsiness_detection/logs'

# Create directories if they don't exist
os.makedirs(MODELS_DIR, exist_ok=True)
os.makedirs(LOGS_DIR, exist_ok=True)

def prepare_data_generators():
    """
    Prepare data generators for training and validation
    
    Returns:
    --------
    train_generator_eyes : tf.keras.preprocessing.image.DirectoryIterator
        Generator for eye training data
    validation_generator_eyes : tf.keras.preprocessing.image.DirectoryIterator
        Generator for eye validation data
    train_generator_yawn : tf.keras.preprocessing.image.DirectoryIterator
        Generator for yawn training data
    validation_generator_yawn : tf.keras.preprocessing.image.DirectoryIterator
        Generator for yawn validation data
    """
    # Data augmentation for training
    train_datagen = ImageDataGenerator(
        rescale=1./255,
        rotation_range=10,
        width_shift_range=0.1,
        height_shift_range=0.1,
        shear_range=0.1,
        zoom_range=0.1,
        horizontal_flip=True,
        fill_mode='nearest',
        validation_split=0.2  # 20% for validation
    )
    
    # Only rescaling for validation
    validation_datagen = ImageDataGenerator(
        rescale=1./255,
        validation_split=0.2
    )
    
    # Prepare eye state generators (Open/Closed)
    train_generator_eyes = train_datagen.flow_from_directory(
        TRAIN_DIR,
        target_size=(IMG_SIZE, IMG_SIZE),
        batch_size=BATCH_SIZE,
        class_mode='categorical',
        color_mode='grayscale',
        classes=['Closed', 'Open'],
        subset='training',
        shuffle=True
    )
    
    validation_generator_eyes = validation_datagen.flow_from_directory(
        TRAIN_DIR,
        target_size=(IMG_SIZE, IMG_SIZE),
        batch_size=BATCH_SIZE,
        class_mode='categorical',
        color_mode='grayscale',
        classes=['Closed', 'Open'],
        subset='validation',
        shuffle=False
    )
    
    # Prepare yawn detection generators (yawn/no_yawn)
    train_generator_yawn = train_datagen.flow_from_directory(
        TRAIN_DIR,
        target_size=(IMG_SIZE, IMG_SIZE),
        batch_size=BATCH_SIZE,
        class_mode='categorical',
        color_mode='grayscale',
        classes=['no_yawn', 'yawn'],
        subset='training',
        shuffle=True
    )
    
    validation_generator_yawn = validation_datagen.flow_from_directory(
        TRAIN_DIR,
        target_size=(IMG_SIZE, IMG_SIZE),
        batch_size=BATCH_SIZE,
        class_mode='categorical',
        color_mode='grayscale',
        classes=['no_yawn', 'yawn'],
        subset='validation',
        shuffle=False
    )
    
    return train_generator_eyes, validation_generator_eyes, train_generator_yawn, validation_generator_yawn

def train_models():
    """
    Train eye state and yawn detection models
    
    Returns:
    --------
    eye_model : tf.keras.Model
        Trained eye state classification model
    yawn_model : tf.keras.Model
        Trained yawn detection model
    """
    print("Preparing data generators...")
    train_generator_eyes, validation_generator_eyes, train_generator_yawn, validation_generator_yawn = prepare_data_generators()
    
    # Get number of training and validation samples
    num_train_samples_eyes = train_generator_eyes.samples
    num_validation_samples_eyes = validation_generator_eyes.samples
    num_train_samples_yawn = train_generator_yawn.samples
    num_validation_samples_yawn = validation_generator_yawn.samples
    
    print(f"Eye state classification: {num_train_samples_eyes} training samples, {num_validation_samples_eyes} validation samples")
    print(f"Yawn detection: {num_train_samples_yawn} training samples, {num_validation_samples_yawn} validation samples")
    
    # Create and train eye state model
    print("\nTraining eye state classification model...")
    eye_model = create_eye_model()
    eye_callbacks = setup_callbacks('eye_model')
    
    eye_history = eye_model.fit(
        train_generator_eyes,
        steps_per_epoch=num_train_samples_eyes // BATCH_SIZE,
        epochs=EPOCHS,
        validation_data=validation_generator_eyes,
        validation_steps=num_validation_samples_eyes // BATCH_SIZE,
        callbacks=eye_callbacks,
        verbose=1
    )
    
    # Plot and save training history
    plot_training_history(eye_history, 'eye_model')
    
    # Create and train yawn detection model
    print("\nTraining yawn detection model...")
    yawn_model = create_yawn_model()
    yawn_callbacks = setup_callbacks('yawn_model')
    
    yawn_history = yawn_model.fit(
        train_generator_yawn,
        steps_per_epoch=num_train_samples_yawn // BATCH_SIZE,
        epochs=EPOCHS,
        validation_data=validation_generator_yawn,
        validation_steps=num_validation_samples_yawn // BATCH_SIZE,
        callbacks=yawn_callbacks,
        verbose=1
    )
    
    # Plot and save training history
    plot_training_history(yawn_history, 'yawn_model')
    
    # Save final models
    eye_model.save(os.path.join(MODELS_DIR, 'eye_model_final.h5'))
    yawn_model.save(os.path.join(MODELS_DIR, 'yawn_model_final.h5'))
    
    print(f"\nFinal models saved to {MODELS_DIR}")
    
    return eye_model, yawn_model

def evaluate_models(eye_model, yawn_model):
    """
    Evaluate trained models and generate performance metrics
    
    Parameters:
    -----------
    eye_model : tf.keras.Model
        Trained eye state classification model
    yawn_model : tf.keras.Model
        Trained yawn detection model
    """
    print("\nEvaluating models...")
    
    # Prepare evaluation data generators (no augmentation, no validation split)
    eval_datagen = ImageDataGenerator(rescale=1./255)
    
    # Eye state evaluation generator
    eval_generator_eyes = eval_datagen.flow_from_directory(
        TRAIN_DIR,
        target_size=(IMG_SIZE, IMG_SIZE),
        batch_size=1,
        class_mode='categorical',
        color_mode='grayscale',
        classes=['Closed', 'Open'],
        shuffle=False
    )
    
    # Yawn detection evaluation generator
    eval_generator_yawn = eval_datagen.flow_from_directory(
        TRAIN_DIR,
        target_size=(IMG_SIZE, IMG_SIZE),
        batch_size=1,
        class_mode='categorical',
        color_mode='grayscale',
        classes=['no_yawn', 'yawn'],
        shuffle=False
    )
    
    # Evaluate eye state model
    print("\nEvaluating eye state classification model...")
    y_true_eyes = eval_generator_eyes.classes
    y_pred_probs_eyes = eye_model.predict(eval_generator_eyes, verbose=1)
    y_pred_eyes = np.argmax(y_pred_probs_eyes, axis=1)
    
    # Calculate metrics for eye state model
    accuracy_eyes = accuracy_score(y_true_eyes, y_pred_eyes)
    precision_eyes = precision_score(y_true_eyes, y_pred_eyes, average='weighted')
    recall_eyes = recall_score(y_true_eyes, y_pred_eyes, average='weighted')
    f1_eyes = f1_score(y_true_eyes, y_pred_eyes, average='weighted')
    
    print(f"Eye State Classification Metrics:")
    print(f"Accuracy: {accuracy_eyes:.4f}")
    print(f"Precision: {precision_eyes:.4f}")
    print(f"Recall: {recall_eyes:.4f}")
    print(f"F1 Score: {f1_eyes:.4f}")
    
    # Generate confusion matrix for eye state model
    cm_eyes = confusion_matrix(y_true_eyes, y_pred_eyes)
    plt.figure(figsize=(8, 6))
    sns.heatmap(cm_eyes, annot=True, fmt='d', cmap='Blues', 
                xticklabels=['Closed', 'Open'], 
                yticklabels=['Closed', 'Open'])
    plt.xlabel('Predicted')
    plt.ylabel('True')
    plt.title('Confusion Matrix - Eye State Classification')
    plt.tight_layout()
    plt.savefig(os.path.join(LOGS_DIR, 'eye_model_confusion_matrix.png'))
    plt.close()
    
    # Evaluate yawn detection model
    print("\nEvaluating yawn detection model...")
    y_true_yawn = eval_generator_yawn.classes
    y_pred_probs_yawn = yawn_model.predict(eval_generator_yawn, verbose=1)
    y_pred_yawn = np.argmax(y_pred_probs_yawn, axis=1)
    
    # Calculate metrics for yawn detection model
    accuracy_yawn = accuracy_score(y_true_yawn, y_pred_yawn)
    precision_yawn = precision_score(y_true_yawn, y_pred_yawn, average='weighted')
    recall_yawn = recall_score(y_true_yawn, y_pred_yawn, average='weighted')
    f1_yawn = f1_score(y_true_yawn, y_pred_yawn, average='weighted')
    
    print(f"Yawn Detection Metrics:")
    print(f"Accuracy: {accuracy_yawn:.4f}")
    print(f"Precision: {precision_yawn:.4f}")
    print(f"Recall: {recall_yawn:.4f}")
    print(f"F1 Score: {f1_yawn:.4f}")
    
    # Generate confusion matrix for yawn detection model
    cm_yawn = confusion_matrix(y_true_yawn, y_pred_yawn)
    plt.figure(figsize=(8, 6))
    sns.heatmap(cm_yawn, annot=True, fmt='d', cmap='Blues', 
                xticklabels=['No Yawn', 'Yawn'], 
                yticklabels=['No Yawn', 'Yawn'])
    plt.xlabel('Predicted')
    plt.ylabel('True')
    plt.title('Confusion Matrix - Yawn Detection')
    plt.tight_layout()
    plt.savefig(os.path.join(LOGS_DIR, 'yawn_model_confusion_matrix.png'))
    plt.close()
    
    # Save evaluation metrics to file
    with open(os.path.join(LOGS_DIR, 'evaluation_metrics.txt'), 'w') as f:
        f.write("Driver Drowsiness Detection System - Model Evaluation Metrics\n")
        f.write("=" * 60 + "\n\n")
        
        f.write("Eye State Classification Metrics:\n")
        f.write(f"Accuracy: {accuracy_eyes:.4f}\n")
        f.write(f"Precision: {precision_eyes:.4f}\n")
        f.write(f"Recall: {recall_eyes:.4f}\n")
        f.write(f"F1 Score: {f1_eyes:.4f}\n\n")
        
        f.write("Yawn Detection Metrics:\n")
        f.write(f"Accuracy: {accuracy_yawn:.4f}\n")
        f.write(f"Precision: {precision_yawn:.4f}\n")
        f.write(f"Recall: {recall_yawn:.4f}\n")
        f.write(f"F1 Score: {f1_yawn:.4f}\n")
    
    print(f"Evaluation metrics saved to {os.path.join(LOGS_DIR, 'evaluation_metrics.txt')}")

if __name__ == "__main__":
    print("Starting model training and evaluation...")
    
    # Train models
    eye_model, yawn_model = train_models()
    
    # Evaluate models
    evaluate_models(eye_model, yawn_model)
    
    print("Model training and evaluation complete!")
