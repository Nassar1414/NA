import os
import numpy as np
import tensorflow as tf
from tensorflow.keras.models import load_model
from tensorflow.keras.utils import to_categorical
from tensorflow.keras.callbacks import ModelCheckpoint, EarlyStopping, ReduceLROnPlateau
import matplotlib.pyplot as plt
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, confusion_matrix
import seaborn as sns
from model_baseline import create_custom_cnn_model, create_ensemble_model, setup_callbacks, plot_training_history

# Define constants
IMG_SIZE = 224
BATCH_SIZE = 32
EPOCHS = 50
DATA_DIR = '/home/ubuntu/driver_drowsiness_detection/data'
PROCESSED_DIR = os.path.join(DATA_DIR, 'processed')
FEATURES_DIR = os.path.join(DATA_DIR, 'features')
MODELS_DIR = '/home/ubuntu/driver_drowsiness_detection/models'
LOGS_DIR = '/home/ubuntu/driver_drowsiness_detection/logs'

# Create directories if they don't exist
os.makedirs(MODELS_DIR, exist_ok=True)
os.makedirs(LOGS_DIR, exist_ok=True)

def load_processed_data(split='train', task='eye'):
    """
    Load processed data for training/validation/testing
    
    Parameters:
    -----------
    split : str
        Data split to load ('train', 'val', or 'test')
    task : str
        Task to load data for ('eye' or 'yawn')
        
    Returns:
    --------
    X : numpy.ndarray
        Input data
    y : numpy.ndarray
        Labels
    """
    print(f"Loading {split} data for {task} detection...")
    
    if task == 'eye':
        categories = ['Closed', 'Open']
    else:  # task == 'yawn'
        categories = ['no_yawn', 'yawn']
    
    X_list = []
    y_list = []
    
    for i, category in enumerate(categories):
        category_path = os.path.join(PROCESSED_DIR, split, category)
        
        if not os.path.exists(category_path):
            print(f"Warning: Category path {category_path} does not exist")
            continue
        
        files = [f for f in os.listdir(category_path) if f.endswith('.npy')]
        
        for file in files:
            # Load processed image
            file_path = os.path.join(category_path, file)
            img = np.load(file_path)
            
            # Add to lists
            X_list.append(img)
            y_list.append(i)
    
    # Convert to numpy arrays
    X = np.array(X_list)
    y = np.array(y_list)
    
    # Convert labels to categorical
    y_categorical = to_categorical(y, num_classes=len(categories))
    
    print(f"  Loaded {X.shape[0]} samples with shape {X.shape[1:]} and {len(categories)} classes")
    
    return X, y_categorical

def train_model(model, X_train, y_train, X_val, y_val, model_name):
    """
    Train a model
    
    Parameters:
    -----------
    model : tensorflow.keras.Model
        Model to train
    X_train : numpy.ndarray
        Training data
    y_train : numpy.ndarray
        Training labels
    X_val : numpy.ndarray
        Validation data
    y_val : numpy.ndarray
        Validation labels
    model_name : str
        Name of the model for saving
        
    Returns:
    --------
    history : tensorflow.keras.callbacks.History
        Training history
    """
    print(f"Training {model_name}...")
    
    # Setup callbacks
    callbacks = setup_callbacks(model_name)
    
    # Train model
    history = model.fit(
        X_train, y_train,
        batch_size=BATCH_SIZE,
        epochs=EPOCHS,
        validation_data=(X_val, y_val),
        callbacks=callbacks,
        verbose=1
    )
    
    # Save final model
    model.save(os.path.join(MODELS_DIR, f"{model_name}_final.h5"))
    
    # Plot training history
    plot_training_history(history, model_name)
    
    return history

def evaluate_model(model, X_test, y_test, model_name, task):
    """
    Evaluate a model
    
    Parameters:
    -----------
    model : tensorflow.keras.Model
        Model to evaluate
    X_test : numpy.ndarray
        Test data
    y_test : numpy.ndarray
        Test labels
    model_name : str
        Name of the model for saving results
    task : str
        Task name ('eye' or 'yawn')
    """
    print(f"Evaluating {model_name}...")
    
    # Get predictions
    y_pred_prob = model.predict(X_test)
    y_pred = np.argmax(y_pred_prob, axis=1)
    y_true = np.argmax(y_test, axis=1)
    
    # Calculate metrics
    accuracy = accuracy_score(y_true, y_pred)
    precision = precision_score(y_true, y_pred, average='weighted')
    recall = recall_score(y_true, y_pred, average='weighted')
    f1 = f1_score(y_true, y_pred, average='weighted')
    
    print(f"  Accuracy: {accuracy:.4f}")
    print(f"  Precision: {precision:.4f}")
    print(f"  Recall: {recall:.4f}")
    print(f"  F1 Score: {f1:.4f}")
    
    # Create confusion matrix
    if task == 'eye':
        labels = ['Closed', 'Open']
    else:  # task == 'yawn'
        labels = ['No Yawn', 'Yawn']
    
    cm = confusion_matrix(y_true, y_pred)
    
    plt.figure(figsize=(8, 6))
    sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', xticklabels=labels, yticklabels=labels)
    plt.xlabel('Predicted')
    plt.ylabel('True')
    plt.title(f'Confusion Matrix - {model_name}')
    plt.tight_layout()
    plt.savefig(os.path.join(LOGS_DIR, f"{model_name}_confusion_matrix.png"))
    plt.close()
    
    # Save metrics to file
    with open(os.path.join(LOGS_DIR, f"{model_name}_metrics.txt"), 'w') as f:
        f.write(f"{model_name} - Evaluation Metrics\n")
        f.write("=" * 40 + "\n\n")
        f.write(f"Accuracy: {accuracy:.4f}\n")
        f.write(f"Precision: {precision:.4f}\n")
        f.write(f"Recall: {recall:.4f}\n")
        f.write(f"F1 Score: {f1:.4f}\n")
    
    return accuracy, precision, recall, f1

def train_and_evaluate_models():
    """
    Train and evaluate all models
    """
    # Load data for eye state detection
    X_train_eye, y_train_eye = load_processed_data(split='train', task='eye')
    X_val_eye, y_val_eye = load_processed_data(split='val', task='eye')
    X_test_eye, y_test_eye = load_processed_data(split='test', task='eye')
    
    # Load data for yawn detection
    X_train_yawn, y_train_yawn = load_processed_data(split='train', task='yawn')
    X_val_yawn, y_val_yawn = load_processed_data(split='val', task='yawn')
    X_test_yawn, y_test_yawn = load_processed_data(split='test', task='yawn')
    
    # Train and evaluate custom CNN for eye state detection
    eye_cnn_model = create_custom_cnn_model(input_shape=(IMG_SIZE, IMG_SIZE, 1), num_classes=2)
    train_model(eye_cnn_model, X_train_eye, y_train_eye, X_val_eye, y_val_eye, "eye_cnn")
    eye_cnn_metrics = evaluate_model(eye_cnn_model, X_test_eye, y_test_eye, "eye_cnn", "eye")
    
    # Train and evaluate ensemble model for eye state detection
    eye_ensemble_model = create_ensemble_model(input_shape=(IMG_SIZE, IMG_SIZE, 1), num_classes=2)
    train_model(eye_ensemble_model, X_train_eye, y_train_eye, X_val_eye, y_val_eye, "eye_ensemble")
    eye_ensemble_metrics = evaluate_model(eye_ensemble_model, X_test_eye, y_test_eye, "eye_ensemble", "eye")
    
    # Train and evaluate custom CNN for yawn detection
    yawn_cnn_model = create_custom_cnn_model(input_shape=(IMG_SIZE, IMG_SIZE, 1), num_classes=2)
    train_model(yawn_cnn_model, X_train_yawn, y_train_yawn, X_val_yawn, y_val_yawn, "yawn_cnn")
    yawn_cnn_metrics = evaluate_model(yawn_cnn_model, X_test_yawn, y_test_yawn, "yawn_cnn", "yawn")
    
    # Train and evaluate ensemble model for yawn detection
    yawn_ensemble_model = create_ensemble_model(input_shape=(IMG_SIZE, IMG_SIZE, 1), num_classes=2)
    train_model(yawn_ensemble_model, X_train_yawn, y_train_yawn, X_val_yawn, y_val_yawn, "yawn_ensemble")
    yawn_ensemble_metrics = evaluate_model(yawn_ensemble_model, X_test_yawn, y_test_yawn, "yawn_ensemble", "yawn")
    
    # Compare models
    print("\nModel Comparison:")
    print("=" * 60)
    print(f"{'Model':<20} {'Accuracy':<10} {'Precision':<10} {'Recall':<10} {'F1 Score':<10}")
    print("-" * 60)
    print(f"{'Eye CNN':<20} {eye_cnn_metrics[0]:<10.4f} {eye_cnn_metrics[1]:<10.4f} {eye_cnn_metrics[2]:<10.4f} {eye_cnn_metrics[3]:<10.4f}")
    print(f"{'Eye Ensemble':<20} {eye_ensemble_metrics[0]:<10.4f} {eye_ensemble_metrics[1]:<10.4f} {eye_ensemble_metrics[2]:<10.4f} {eye_ensemble_metrics[3]:<10.4f}")
    print(f"{'Yawn CNN':<20} {yawn_cnn_metrics[0]:<10.4f} {yawn_cnn_metrics[1]:<10.4f} {yawn_cnn_metrics[2]:<10.4f} {yawn_cnn_metrics[3]:<10.4f}")
    print(f"{'Yawn Ensemble':<20} {yawn_ensemble_metrics[0]:<10.4f} {yawn_ensemble_metrics[1]:<10.4f} {yawn_ensemble_metrics[2]:<10.4f} {yawn_ensemble_metrics[3]:<10.4f}")
    
    # Save comparison to file
    with open(os.path.join(LOGS_DIR, "model_comparison.txt"), 'w') as f:
        f.write("Driver Drowsiness Detection - Model Comparison\n")
        f.write("=" * 60 + "\n\n")
        f.write(f"{'Model':<20} {'Accuracy':<10} {'Precision':<10} {'Recall':<10} {'F1 Score':<10}\n")
        f.write("-" * 60 + "\n")
        f.write(f"{'Eye CNN':<20} {eye_cnn_metrics[0]:<10.4f} {eye_cnn_metrics[1]:<10.4f} {eye_cnn_metrics[2]:<10.4f} {eye_cnn_metrics[3]:<10.4f}\n")
        f.write(f"{'Eye Ensemble':<20} {eye_ensemble_metrics[0]:<10.4f} {eye_ensemble_metrics[1]:<10.4f} {eye_ensemble_metrics[2]:<10.4f} {eye_ensemble_metrics[3]:<10.4f}\n")
        f.write(f"{'Yawn CNN':<20} {yawn_cnn_metrics[0]:<10.4f} {yawn_cnn_metrics[1]:<10.4f} {yawn_cnn_metrics[2]:<10.4f} {yawn_cnn_metrics[3]:<10.4f}\n")
        f.write(f"{'Yawn Ensemble':<20} {yawn_ensemble_metrics[0]:<10.4f} {yawn_ensemble_metrics[1]:<10.4f} {yawn_ensemble_metrics[2]:<10.4f} {yawn_ensemble_metrics[3]:<10.4f}\n")

if __name__ == "__main__":
    train_and_evaluate_models()
