import os
import numpy as np
import tensorflow as tf
from tensorflow.keras.utils import to_categorical
from tensorflow.keras.callbacks import ModelCheckpoint, EarlyStopping, ReduceLROnPlateau
import matplotlib.pyplot as plt
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, confusion_matrix
import seaborn as sns
from model_memory_efficient import create_memory_efficient_model, create_lightweight_ensemble_model, setup_callbacks, plot_training_history

# Define constants with memory-efficient settings
IMG_SIZE = 128  # Reduced from 224 to save memory
BATCH_SIZE = 16  # Reduced from 32 to save memory
EPOCHS = 30
DATA_DIR = '/home/ubuntu/driver_drowsiness_detection/data'
PROCESSED_DIR = os.path.join(DATA_DIR, 'processed')
FEATURES_DIR = os.path.join(DATA_DIR, 'features')
MODELS_DIR = '/home/ubuntu/driver_drowsiness_detection/models'
LOGS_DIR = '/home/ubuntu/driver_drowsiness_detection/logs'

# Create directories if they don't exist
os.makedirs(MODELS_DIR, exist_ok=True)
os.makedirs(LOGS_DIR, exist_ok=True)

def load_processed_data_in_batches(split='train', task='eye', batch_size=None):
    """
    Load processed data in batches to reduce memory usage
    
    Parameters:
    -----------
    split : str
        Data split to load ('train', 'val', or 'test')
    task : str
        Task to load data for ('eye' or 'yawn')
    batch_size : int
        Batch size for loading data, if None, load all data
        
    Returns:
    --------
    data_generator : generator
        Generator that yields batches of (X, y) data
    total_samples : int
        Total number of samples
    """
    print(f"Loading {split} data for {task} detection in batches...")
    
    if task == 'eye':
        categories = ['Closed', 'Open']
    else:  # task == 'yawn'
        categories = ['no_yawn', 'yawn']
    
    # Get all file paths and labels
    file_paths = []
    labels = []
    
    for i, category in enumerate(categories):
        category_path = os.path.join(PROCESSED_DIR, split, category)
        
        if not os.path.exists(category_path):
            print(f"Warning: Category path {category_path} does not exist")
            continue
        
        files = [f for f in os.listdir(category_path) if f.endswith('.npy')]
        
        for file in files:
            file_path = os.path.join(category_path, file)
            file_paths.append(file_path)
            labels.append(i)
    
    # Convert labels to categorical
    labels = np.array(labels)
    labels_categorical = to_categorical(labels, num_classes=len(categories))
    
    total_samples = len(file_paths)
    print(f"  Found {total_samples} samples for {len(categories)} classes")
    
    if batch_size is None:
        # Load all data at once (may cause memory issues)
        X_list = []
        
        for file_path in file_paths:
            img = np.load(file_path)
            # Resize if necessary
            if img.shape[0] != IMG_SIZE or img.shape[1] != IMG_SIZE:
                img = tf.image.resize(img, [IMG_SIZE, IMG_SIZE]).numpy()
            X_list.append(img)
        
        X = np.array(X_list)
        
        def data_generator():
            yield X, labels_categorical
    else:
        # Create a generator that yields batches
        def data_generator():
            indices = np.arange(total_samples)
            np.random.shuffle(indices)
            
            for start_idx in range(0, total_samples, batch_size):
                end_idx = min(start_idx + batch_size, total_samples)
                batch_indices = indices[start_idx:end_idx]
                
                X_batch = []
                y_batch = []
                
                for idx in batch_indices:
                    file_path = file_paths[idx]
                    img = np.load(file_path)
                    # Resize if necessary
                    if img.shape[0] != IMG_SIZE or img.shape[1] != IMG_SIZE:
                        img = tf.image.resize(img, [IMG_SIZE, IMG_SIZE]).numpy()
                    X_batch.append(img)
                    y_batch.append(labels_categorical[idx])
                
                yield np.array(X_batch), np.array(y_batch)
    
    return data_generator(), total_samples

def train_model_with_memory_efficiency(model, data_generator, total_samples, validation_data, model_name):
    """
    Train a model with memory efficiency in mind
    
    Parameters:
    -----------
    model : tensorflow.keras.Model
        Model to train
    data_generator : generator
        Generator that yields batches of (X, y) data
    total_samples : int
        Total number of samples
    validation_data : tuple
        Validation data as (X_val, y_val)
    model_name : str
        Name of the model for saving
        
    Returns:
    --------
    history : tensorflow.keras.callbacks.History
        Training history
    """
    print(f"Training {model_name} with memory efficiency...")
    
    # Setup callbacks
    callbacks = setup_callbacks(model_name)
    
    # Calculate steps per epoch
    steps_per_epoch = (total_samples + BATCH_SIZE - 1) // BATCH_SIZE
    
    # Train model
    history = model.fit(
        data_generator,
        steps_per_epoch=steps_per_epoch,
        epochs=EPOCHS,
        validation_data=validation_data,
        callbacks=callbacks,
        verbose=1
    )
    
    # Save final model
    model.save(os.path.join(MODELS_DIR, f"{model_name}_final.h5"))
    
    # Plot training history
    plot_training_history(history, model_name)
    
    return history

def evaluate_model(model, X_test, y_test, model_name, task):
    """
    Evaluate a model
    
    Parameters:
    -----------
    model : tensorflow.keras.Model
        Model to evaluate
    X_test : numpy.ndarray
        Test data
    y_test : numpy.ndarray
        Test labels
    model_name : str
        Name of the model for saving results
    task : str
        Task name ('eye' or 'yawn')
    """
    print(f"Evaluating {model_name}...")
    
    # Get predictions
    y_pred_prob = model.predict(X_test, batch_size=BATCH_SIZE)
    y_pred = np.argmax(y_pred_prob, axis=1)
    y_true = np.argmax(y_test, axis=1)
    
    # Calculate metrics
    accuracy = accuracy_score(y_true, y_pred)
    precision = precision_score(y_true, y_pred, average='weighted')
    recall = recall_score(y_true, y_pred, average='weighted')
    f1 = f1_score(y_true, y_pred, average='weighted')
    
    print(f"  Accuracy: {accuracy:.4f}")
    print(f"  Precision: {precision:.4f}")
    print(f"  Recall: {recall:.4f}")
    print(f"  F1 Score: {f1:.4f}")
    
    # Create confusion matrix
    if task == 'eye':
        labels = ['Closed', 'Open']
    else:  # task == 'yawn'
        labels = ['No Yawn', 'Yawn']
    
    cm = confusion_matrix(y_true, y_pred)
    
    plt.figure(figsize=(8, 6))
    sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', xticklabels=labels, yticklabels=labels)
    plt.xlabel('Predicted')
    plt.ylabel('True')
    plt.title(f'Confusion Matrix - {model_name}')
    plt.tight_layout()
    plt.savefig(os.path.join(LOGS_DIR, f"{model_name}_confusion_matrix.png"))
    plt.close()
    
    # Save metrics to file
    with open(os.path.join(LOGS_DIR, f"{model_name}_metrics.txt"), 'w') as f:
        f.write(f"{model_name} - Evaluation Metrics\n")
        f.write("=" * 40 + "\n\n")
        f.write(f"Accuracy: {accuracy:.4f}\n")
        f.write(f"Precision: {precision:.4f}\n")
        f.write(f"Recall: {recall:.4f}\n")
        f.write(f"F1 Score: {f1:.4f}\n")
    
    return accuracy, precision, recall, f1

def train_and_evaluate_models_memory_efficient():
    """
    Train and evaluate models with memory efficiency in mind
    """
    # Load validation and test data (smaller sets, can load all at once)
    X_val_eye, y_val_eye = next(load_processed_data_in_batches(split='val', task='eye')[0])
    X_test_eye, y_test_eye = next(load_processed_data_in_batches(split='test', task='eye')[0])
    
    X_val_yawn, y_val_yawn = next(load_processed_data_in_batches(split='val', task='yawn')[0])
    X_test_yawn, y_test_yawn = next(load_processed_data_in_batches(split='test', task='yawn')[0])
    
    # Get training data generators
    train_gen_eye, train_samples_eye = load_processed_data_in_batches(split='train', task='eye', batch_size=BATCH_SIZE)
    train_gen_yawn, train_samples_yawn = load_processed_data_in_batches(split='train', task='yawn', batch_size=BATCH_SIZE)
    
    # Train and evaluate memory-efficient model for eye state detection
    eye_model = create_memory_efficient_model(input_shape=(IMG_SIZE, IMG_SIZE, 1), num_classes=2)
    train_model_with_memory_efficiency(eye_model, train_gen_eye, train_samples_eye, (X_val_eye, y_val_eye), "eye_efficient")
    eye_metrics = evaluate_model(eye_model, X_test_eye, y_test_eye, "eye_efficient", "eye")
    
    # Train and evaluate memory-efficient model for yawn detection
    yawn_model = create_memory_efficient_model(input_shape=(IMG_SIZE, IMG_SIZE, 1), num_classes=2)
    train_model_with_memory_efficiency(yawn_model, train_gen_yawn, train_samples_yawn, (X_val_yawn, y_val_yawn), "yawn_efficient")
    yawn_metrics = evaluate_model(yawn_model, X_test_yawn, y_test_yawn, "yawn_efficient", "yawn")
    
    # Compare models
    print("\nModel Comparison:")
    print("=" * 60)
    print(f"{'Model':<20} {'Accuracy':<10} {'Precision':<10} {'Recall':<10} {'F1 Score':<10}")
    print("-" * 60)
    print(f"{'Eye Efficient':<20} {eye_metrics[0]:<10.4f} {eye_metrics[1]:<10.4f} {eye_metrics[2]:<10.4f} {eye_metrics[3]:<10.4f}")
    print(f"{'Yawn Efficient':<20} {yawn_metrics[0]:<10.4f} {yawn_metrics[1]:<10.4f} {yawn_metrics[2]:<10.4f} {yawn_metrics[3]:<10.4f}")
    
    # Save comparison to file
    with open(os.path.join(LOGS_DIR, "model_comparison_efficient.txt"), 'w') as f:
        f.write("Driver Drowsiness Detection - Memory-Efficient Model Comparison\n")
        f.write("=" * 60 + "\n\n")
        f.write(f"{'Model':<20} {'Accuracy':<10} {'Precision':<10} {'Recall':<10} {'F1 Score':<10}\n")
        f.write("-" * 60 + "\n")
        f.write(f"{'Eye Efficient':<20} {eye_metrics[0]:<10.4f} {eye_metrics[1]:<10.4f} {eye_metrics[2]:<10.4f} {eye_metrics[3]:<10.4f}\n")
        f.write(f"{'Yawn Efficient':<20} {yawn_metrics[0]:<10.4f} {yawn_metrics[1]:<10.4f} {yawn_metrics[2]:<10.4f} {yawn_metrics[3]:<10.4f}\n")

if __name__ == "__main__":
    train_and_evaluate_models_memory_efficient()
