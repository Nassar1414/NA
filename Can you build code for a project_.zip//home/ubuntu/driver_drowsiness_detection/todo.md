# Driver Drowsiness Detection System - Todo List

## Setup and Environment
- [x] Create project directory structure
- [x] Install required dependencies (TensorFlow, OpenCV, scikit-learn)
- [ ] Set up virtual environment (optional)

## Data Collection & Preprocessing
- [x] Download Drowsiness Dataset by Dheeraj Perumandla from Kaggle
- [x] Preprocess dataset images (resize, normalize, grayscale)
- [x] Apply data augmentation (rotation, flipping, brightness adjustment)
- [x] Split data into training, validation, and testing sets

## Model Development
- [x] Build CNN architecture for eye state classification
- [x] Implement model training pipeline
- [x] Evaluate model with metrics (accuracy, precision, recall, F1-score)
- [x] Save and export trained model

## Real-Time Inference System
- [ ] Implement webcam input capture using OpenCV
- [ ] Detect face and eyes using Haar cascades or Mediapipe
- [ ] Classify eye state frame-by-frame using the CNN
- [ ] Implement drowsiness detection logic
- [ ] Add visual and audio alerts

## Final Product & Deployment
- [ ] Optimize for real-time performance
- [ ] Create user interface
- [ ] Add logging functionality
- [ ] Write documentation
- [ ] Package as a desktop application
