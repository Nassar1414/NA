# Driver Drowsiness Detection System

## Project Overview
This project implements a comprehensive Driver Drowsiness Detection System using artificial intelligence and computer vision. The system operates in real-time using webcam input to detect early signs of driver fatigue, such as prolonged eye closure or yawning.

## Features
- Real-time drowsiness detection using webcam input
- Eye state classification (open/closed)
- Yawn detection
- Visual and audio alerts when drowsiness is detected
- Memory-efficient implementations for systems with limited resources
- Optimization tools for deployment to web and mobile platforms

## Project Structure
```
driver_drowsiness_detection/
├── data/                      # Dataset and processed data
│   ├── train/                 # Original training data
│   ├── processed/             # Preprocessed images
│   ├── features/              # Extracted features
│   └── analysis/              # Dataset analysis results
├── models/                    # Trained models
├── logs/                      # Training logs and evaluation metrics
├── optimized_models/          # Optimized models for deployment
├── sounds/                    # Alert sounds
└── src/                       # Source code
    ├── preprocess.py          # Data preprocessing
    ├── feature_extraction.py  # Feature extraction
    ├── model_baseline.py      # Model architecture
    ├── model_memory_efficient.py # Memory-efficient model architecture
    ├── train_improved.py      # Training script
    ├── train_memory_efficient.py # Memory-efficient training script
    ├── real_time_detection.py # Real-time detection system
    └── optimize_models.py     # Model optimization for deployment
```

## Installation
1. Clone the repository
2. Install dependencies:
```bash
pip install tensorflow opencv-python scikit-learn pillow matplotlib pandas tqdm seaborn
```

## Usage

### Data Preprocessing
```bash
python src/preprocess.py
```
This script preprocesses the dataset by:
- Standardizing images to 224x224 pixels
- Converting to grayscale
- Applying histogram equalization
- Creating train/validation/test splits (70%/15%/15%)

### Feature Extraction
```bash
python src/feature_extraction.py
```
This script extracts features using transfer learning with pre-trained models:
- MobileNetV2 or ResNet50 as feature extractors
- Saves extracted features for model training

### Model Training
For standard training (may require significant memory):
```bash
python src/train_improved.py
```

For memory-efficient training:
```bash
python src/train_memory_efficient.py
```

### Real-Time Detection
```bash
python src/real_time_detection.py
```
This script runs the real-time drowsiness detection system using:
- Webcam input for video capture
- Face and eye detection using Haar cascades
- Trained models for eye state and yawn classification
- Visual and audio alerts when drowsiness is detected

## Model Architectures

### Baseline Models
- **Custom CNN**: Convolutional Neural Network with batch normalization and dropout
- **Ensemble Model**: Multiple pathway CNN with different filter sizes

### Memory-Efficient Models
- **Memory-Efficient CNN**: Reduced size and complexity for systems with limited resources
- **Lightweight Ensemble**: Simplified ensemble architecture with fewer parameters

## Performance Optimization
The system includes several optimizations:
- Memory-efficient implementations for training
- Batch loading of data to reduce memory usage
- Reduced image size and model complexity options
- Tools for converting models to deployment-friendly formats

## Integration with ClearML
The code is designed to be compatible with ClearML for experiment tracking and model management. The trained models can be easily integrated with ClearML for further optimization and deployment.

## License
This project is provided for educational and research purposes only.
